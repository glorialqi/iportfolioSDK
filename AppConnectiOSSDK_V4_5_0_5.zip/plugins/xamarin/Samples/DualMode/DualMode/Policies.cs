﻿//-----------------------------------------------------------------------
// <copyright file="Policies.cs" company="MobileIron">
//     Copyright (c) 2015 MobileIron. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using Foundation;
using UIKit;

using AppConnectBinding;

namespace DualMode
{
	public enum DualModeState : uint
	{
		// App has not yet selected a mode. Awaiting AppConnectDelegate.ManagedPolicyChangedTo() to select a mode.
		Undecided = 0,
		// App is in non-AppConnect mode
		NonACMode,
		// App is in AppConnect mode
		ACMode,
		// User requested AC mode. Awaiting AppConnectDelegate.ManagedPolicyChangedTo() before allowing the mode change.
		PendingACMode,
        // App Connect is unavailable for now.
        ACNotAvailable,
	}

    public class Policies : AppConnectDelegate
	{
		private const string kDualModeStateDefaultsKey = "DualModeState";

		private AppConnect ac = null;

		private DualModeState state = DualModeState.Undecided;

		public DualModeState State {
			set {
				this.state = value;
				NSUserDefaults.StandardUserDefaults.SetInt ((int)this.state, kDualModeStateDefaultsKey);
				NSUserDefaults.StandardUserDefaults.Synchronize ();
			}
			get {
				return this.state;
			}
		}

		public static Policies Instance {
			private set;
			get;
		} = null;

		public bool AllowCopy {
			get {
				switch (this.State) {
				case DualModeState.Undecided:
				case DualModeState.NonACMode:
				case DualModeState.PendingACMode:
                case DualModeState.ACNotAvailable:
					return true;
				case DualModeState.ACMode:
					return ((this.ac.PasteboardPolicy == ACPasteboardPolicy.Authorized) || (this.ac.PasteboardPolicy == ACPasteboardPolicy.SecureCopy));
				default:
					return false;
				}
			}
		}

		// Disallow public instantiation.
		private Policies ()
		{
		}

		private Policies (NSDictionary launchOptions)
		{
			// Restore dual mode state
			var storedDualModeState = (DualModeState)(int)NSUserDefaults.StandardUserDefaults.IntForKey (kDualModeStateDefaultsKey);
			if (storedDualModeState < 0 || storedDualModeState > DualModeState.PendingACMode) {
				// Unknown value. Discard it.
				storedDualModeState = DualModeState.Undecided;
			}
			this.State = storedDualModeState;

			this.ac = null;
			if (this.State != DualModeState.NonACMode && AppConnect.ShouldStartAppConnect) {
				AppConnect.InitWithDelegate (this);
				this.ac = AppConnect.SharedInstance;
				this.ac.StartWithLaunchOptions (launchOptions);
			}
            else if(this.State == DualModeState.Undecided) {
                this.State = DualModeState.ACNotAvailable;
            }
		}

		public static void Initialize (NSDictionary launchOptions)
		{
			if (Instance != null) {
				throw new Exception ("Logic error in call to Policies method " + System.Reflection.MethodBase.GetCurrentMethod ().Name + ". Method must be called only once.");
			}
			Policies.Instance = new Policies (launchOptions);
		}

		public void SwitchToNonACMode ()
		{
			if (this.State != DualModeState.ACMode && this.State != DualModeState.PendingACMode) {
				throw new Exception ("Logic error in call to Policies method " + System.Reflection.MethodBase.GetCurrentMethod ().Name + ". State must be ACMode or PendingACMode. State = " + this.State);
			}

			AppConnectLog.LogAtLevel (ACLogLevel.Status, "Switched to non-AppConnect mode.");
			Notes.RemoveData ();
			this.State = DualModeState.NonACMode;
			this.ac.Retire ();
			this.ac.Stop ();
			this.ac = null;
			var appDelegate = (DualModeAppDelegate)((AppConnectUIApplication)UIApplication.SharedApplication).OriginalDelegate;
			appDelegate.NonAcModeChangeCompleted ();
		}

		public void AttemptSwitchToACMode ()
		{
			if (this.State == DualModeState.PendingACMode) {
				return;
			}
			if (this.State != DualModeState.NonACMode) {
				throw new Exception ("Logic error in call to Policies method " + System.Reflection.MethodBase.GetCurrentMethod ().Name + ". State must be NonACMode. Current sate = " + this.State);
			}

			AppConnectLog.LogAtLevel (ACLogLevel.Status, "Attempting to switch to AppConnect mode.");

			this.State = DualModeState.PendingACMode;
			AppConnect.InitWithDelegate (this);
			this.ac = AppConnect.SharedInstance;
			this.ac.StartWithLaunchOptions (null);
		}

		// Return value indicates whether the message has been set.
		public bool DisplayAuthMessage (out string authMessage)
		{
			authMessage = "";
			switch (this.State) {
			case DualModeState.Undecided:
				authMessage = "Determining mode";
				return true;
			case DualModeState.NonACMode:
			case DualModeState.PendingACMode:
            case DualModeState.ACNotAvailable:
				return false;
			case DualModeState.ACMode:
				{
					if ((this.ac == null) || !this.ac.Ready) {
						authMessage = "AppConnect is not ready yet";
						return true;
					}

					switch (this.ac.AuthState) {
					case ACAuthState.Authorized:
						return false;
					case ACAuthState.Unauthorized:
						authMessage = "You are not currently authorized to use this app for the following reason(s):\n\n" + this.ac.AuthMessage;
						return true;
					case ACAuthState.Retired:
						authMessage = "You are not currently authorized to use this app, and your notes have been deleted, for the following reason(s):\n\n" + this.ac.AuthMessage;
						return true;
					default:
						return false;
					}

				}
			default:
				return false;
			}
		}

		#region AppConnect Delegate required

		public override void AppConnectIsReady (AppConnect appConnect)
		{
			var appDelegate = (DualModeAppDelegate)((AppConnectUIApplication)UIApplication.SharedApplication).OriginalDelegate;
			appDelegate.RefreshUI ();
		}

		public override void AuthStateChanged (AppConnect appConnect, ACAuthState newAuthState, string message)
		{
			var appDelegate = (DualModeAppDelegate)((AppConnectUIApplication)UIApplication.SharedApplication).OriginalDelegate;
			switch (this.State) {
			case DualModeState.Undecided:
			case DualModeState.NonACMode:
			case DualModeState.PendingACMode:
            case DualModeState.ACNotAvailable:
					// Nothing to do
				break;
			case DualModeState.ACMode:
				if (newAuthState == ACAuthState.Retired) {
					Notes.RemoveData ();
				}
				appDelegate.RefreshUI ();
				break;
			}
			appConnect.AuthStateApplied (ACPolicyState.Applied, null);
		}

		#endregion

		#region AppConnect Delegate optional

		public override void ManagedPolicyChanged (AppConnect appConnect, ACManagedPolicy newManagedPolicy)
		{
			var appDelegate = (DualModeAppDelegate)((AppConnectUIApplication)UIApplication.SharedApplication).OriginalDelegate;
			switch (this.State) {
			case DualModeState.Undecided:
            case DualModeState.ACNotAvailable:
				{
					// Initial mode selected
					switch (newManagedPolicy) {
					case ACManagedPolicy.Unknown:
						{
							// Nothing to do yet.
							break;
						}
					case ACManagedPolicy.Unmanaged:
						{
							AppConnectLog.LogAtLevel (ACLogLevel.Status, "App entering non-AppConnect mode.");
							this.ac.Retire ();
							this.ac.Stop ();
							this.ac = null;
							this.State = DualModeState.NonACMode;
							appDelegate.RefreshUI ();
							break;
						}
					case ACManagedPolicy.Managed:
						{
							AppConnectLog.LogAtLevel (ACLogLevel.Status, "App entering AppConnect mode.");
							this.State = DualModeState.ACMode;
							appDelegate.RefreshUI ();
							break;
						}
					}
					break;
				}
			case DualModeState.NonACMode:
			case DualModeState.ACMode:
					// Nothing to do
				break;
			case DualModeState.PendingACMode:
				{
					// Attempt to change to AC Mode
					switch (newManagedPolicy) {
					case ACManagedPolicy.Unknown:
							// Nothing to do yet.
						break;
					case ACManagedPolicy.Unmanaged:
						{
							AppConnectLog.LogAtLevel (ACLogLevel.Status, "Switch to AppConnect mode failed.");
							this.State = DualModeState.NonACMode;
							var authMessage = this.ac.Ready ? this.ac.AuthMessage : "This app is not managed.";
							this.ac.Retire ();
							this.ac.Stop ();
							this.ac = null;
							appDelegate.ACModeChangeCompleted (false, authMessage);
							break;
						}
					case ACManagedPolicy.Managed:
						{
							AppConnectLog.LogAtLevel (ACLogLevel.Status, "Switch to AppConnect mode succeeded.");
							this.State = DualModeState.ACMode;
							if (this.ac.AuthState == ACAuthState.Retired) {
								Notes.RemoveData ();
								appDelegate.RefreshUI ();
							}
							appDelegate.ACModeChangeCompleted (true, null);
							break;
						}
					}
					break;
				}
			}
		}

		public override void SecureServicesAvailabilityChanged (AppConnect appConnect, ACSecureServicesAvailability secureServicesAvailability)
		{
		}

		public override void PasteboardPolicyChanged (AppConnect appConnect, ACPasteboardPolicy newPasteboardPolicy)
		{
			this.ac.PasteboardPolicyApplied (ACPolicyState.Applied, null);
		}

		public override void SecureFileIOPolicyChanged (AppConnect appConnect, ACSecureFileIOPolicy newSecureFileIOPolicy)
		{
			this.ac.SecureFileIOPolicyApplied (ACPolicyState.Applied, null);
		}

		#endregion
	}
}
