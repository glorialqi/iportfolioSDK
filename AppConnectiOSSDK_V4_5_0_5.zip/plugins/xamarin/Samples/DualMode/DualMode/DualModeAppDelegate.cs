﻿using Foundation;
using UIKit;

namespace DualMode
{
    // The UIApplicationDelegate for the application. This class is responsible for launching the
    // User Interface of the application, as well as listening (and optionally responding) to application events from iOS.
    [Register("DualModeAppDelegate")]
    public class DualModeAppDelegate : UIApplicationDelegate, IUISplitViewControllerDelegate
    {
        // class-level declarations

        public override UIWindow Window
        {
            get;
            set;
        }

        private bool showingAppConnectAuthMessage { get; set; }

        public override bool FinishedLaunching(UIApplication application, NSDictionary launchOptions)
        {

            // Override point for customization after application launch.
            var splitViewController = (UISplitViewController)Window.RootViewController;
            var navigationController = (UINavigationController)splitViewController.ViewControllers[1];
            navigationController.TopViewController.NavigationItem.LeftBarButtonItem = splitViewController.DisplayModeButtonItem;
            splitViewController.WeakDelegate = this;

            Policies.Initialize(launchOptions);

            RefreshUI();

            return true;
        }

        public override void OnResignActivation(UIApplication application)
        {
            // Invoked when the application is about to move from active to inactive state.
            // This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) 
            // or when the user quits the application and it begins the transition to the background state.
            // Games should use this method to pause the game.
        }

        public override void DidEnterBackground(UIApplication application)
        {
            // Use this method to release shared resources, save user data, invalidate timers and store the application state.
            // If your application supports background exection this method is called instead of WillTerminate when the user quits.
        }

        public override void WillEnterForeground(UIApplication application)
        {
            // Called as part of the transiton from background to active state.
            // Here you can undo many of the changes made on entering the background.
        }

        public override void OnActivated(UIApplication application)
        {
            // Restart any tasks that were paused (or not yet started) while the application was inactive. 
            // If the application was previously in the background, optionally refresh the user interface.
        }

        public override void WillTerminate(UIApplication application)
        {
            // Called when the application is about to terminate. Save data, if needed. See also DidEnterBackground.
        }

        class SplitViewControllerDelegate : UISplitViewControllerDelegate
        {
            public override void WillChangeDisplayMode(UISplitViewController svc, UISplitViewControllerDisplayMode displayMode)
            {
                if (displayMode != UISplitViewControllerDisplayMode.PrimaryHidden)
                {
                    svc.View.EndEditing(true);
                }
            }
        }

        private NotesViewController master { get; set; }
        private NotesDetailViewController detail { get; set; }

        private void SetupSplitViewController(UISplitViewController splitViewController) {
            var numberOfViewControllers = splitViewController.ViewControllers.Length;
            UINavigationController masterNavigationController = (UINavigationController)splitViewController.ViewControllers[0];
            UINavigationController detailNavigationController = null;
            if (numberOfViewControllers == 1) {
                master = (NotesViewController)masterNavigationController.ViewControllers[0];
                if (masterNavigationController.ViewControllers.Length > 1) {
                    detailNavigationController = (UINavigationController)masterNavigationController.TopViewController;
                }
                else {
                    detailNavigationController = null;
                }
            }
            else {
                master = (NotesViewController)masterNavigationController.TopViewController;
                detailNavigationController = (UINavigationController)splitViewController.ViewControllers[numberOfViewControllers - 1];
            }

            if (null != detailNavigationController) {
                detail = (NotesDetailViewController)detailNavigationController.TopViewController;
                detail.Delegate = master;
            }
            splitViewController.Delegate = new SplitViewControllerDelegate();
            splitViewController.PreferredDisplayMode = UISplitViewControllerDisplayMode.Automatic;
        }

        private void LaunchInAppConnectUnauthorizedState(string authMessage) {
            UIStoryboard storyboard = Window.RootViewController.Storyboard;
            UINavigationController mainViewController = (UINavigationController)storyboard.InstantiateViewController("UnauthorizedScreen");
            AuthMessageViewController topViewController = (AuthMessageViewController)mainViewController.TopViewController;
            topViewController.messageText = authMessage;

            Window.RootViewController = mainViewController;
            showingAppConnectAuthMessage = true;
        }

        private void SwitchToRootView() {
            if (showingAppConnectAuthMessage) {
                UIStoryboard storyboard = UIStoryboard.FromName("Main", null);
                UISplitViewController splitViewController = (UISplitViewController)storyboard.InstantiateInitialViewController();
                SetupSplitViewController(splitViewController);
                Window.RootViewController = splitViewController;
                showingAppConnectAuthMessage = false;
            }
        }

        public void RefreshUI()
        {
            string authMessage = null;
            bool displayAuthMessage = Policies.Instance.DisplayAuthMessage(out authMessage);
            if (showingAppConnectAuthMessage) {
                if (displayAuthMessage) {
                    UINavigationController mainViewController = (UINavigationController)Window.RootViewController;
                    AuthMessageViewController authMessageViewController = (AuthMessageViewController)mainViewController.TopViewController;
                    if (authMessageViewController is AuthMessageViewController) {
                        authMessageViewController.messageText = authMessage;
                    }
                }
                else {
                    SwitchToRootView();
                }
            }
            else {
                if (displayAuthMessage) {
                    LaunchInAppConnectUnauthorizedState(authMessage);
                }
                else {
                    SetupSplitViewController((UISplitViewController)Window.RootViewController);
                    master.RefreshUI();
                    detail.Reset();
                }
            }
        }

        #region AppConnect delegate methods

        public void ACModeChangeCompleted(bool success, string reason)
        {
            /* Callback when transition to managed mode has completed */
            RefreshUI();
            string alertText = success ? "This app is now managed by MobileIron." : "Failed to enable MobileIron management of this app.\n\nReason: " + reason;
            UIAlertController alert = UIAlertController.Create("MobileIron Management", alertText, UIAlertControllerStyle.Alert);
            UIAlertAction okAction = UIAlertAction.Create("OK", UIAlertActionStyle.Default, null);
            alert.AddAction(okAction);
            Window.RootViewController.PresentViewController(alert, true, null);
        }

        public void NonAcModeChangeCompleted()
        {
            /* Callback when transition to unmanaged mode has completed */
            RefreshUI();
        }

        #endregion
    }
}

