﻿//-----------------------------------------------------------------------
// <copyright file="Notes.cs" company="MobileIron">
//     Copyright (c) 2015 MobileIron. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using Foundation;
using AppConnectBinding;

namespace DualMode
{
	public class Notes
	{
		public const string kNoteListFilename = "notelist";
		public const string kNoteFilenameBase = "note";

		// Disallow public instantiation.
		private Notes ()
		{
		}

		public static string[] ListOfNotes ()
		{
			NSString[] nativeStrings = ListOfNotesNative ();
			NSArray nativeArray = NSArray.FromNSObjects (nativeStrings);
			// NSArray.StringArrayFromHandle() uses direct handle to ObjC object.
			string[] strings = NSArray.StringArrayFromHandle (nativeArray.Handle);
			return strings;
		}

		private static NSString[] ListOfNotesNative ()
		{
			Policies p = Policies.Instance;

			NSFileManager fileManager = NSFileManager.DefaultManager;
			if (!fileManager.FileExists (FilepathForNoteList)) {
				return new NSString[0];
			}
			NSArray nodeList = null;
			try {
				nodeList = (NSArray)NSKeyedUnarchiver.UnarchiveFile (FilepathForNoteList);
			} catch (Exception e) {
				AppConnectLog.LogAtLevel (ACLogLevel.Error, "Exception: {0}", e);
				nodeList = null;
				throw e;
			}

			return NSArray.FromArray<NSString> (nodeList);
		}

		public static NSString NoteContent (uint index)
		{
			NSData noteData = NSData.FromFile (FilepathForNoteIndex (index));
			NSString noteContent = new NSString (noteData, NSStringEncoding.UTF8);
			return noteContent;
		}

		public static uint AddEmptyNote ()
		{
			NSString[] noteList = ListOfNotesNative ();
			uint newNoteIndex = (uint)noteList.Length;
			if (!SaveNote (NSString.Empty, newNoteIndex)) {
				return uint.MaxValue;
			}

			Array.Resize<NSString> (ref noteList, noteList.Length + 1);
			noteList [newNoteIndex] = NSString.Empty;
			if (!SaveNoteList (ref noteList)) {
				DeleteNote (newNoteIndex);
				return uint.MaxValue;
			}
			return newNoteIndex;
		}

		public static void UpdateNote (string content, uint index)
		{
			if (content == null) {
				throw new Exception ("Content cannot be null.");
			}
			UpdateNote (new NSString (content), index);
		}

		public static void UpdateNote (NSString content, uint index)
		{
			if (content == null) {
				throw new Exception ("Content cannot be null.");
			}

			NSString[] noteList = ListOfNotesNative ();
			if (index >= noteList.Length) {
				throw new Exception ("Index out of bounds.");
			}

			SaveNote (content, index);
			NSString title = titleForContent (content);
			noteList [index] = title;
			SaveNoteList (ref noteList);
		}

		public static void RemoveData ()
		{
			NSError error = null;
			bool success = NSFileManager.DefaultManager.Remove (ApplicationSupportDirectoryPath, out error);
			if (!success) {
				AppConnectLog.LogAtLevel (ACLogLevel.Error, "NSError: {0}", error);
			}
		}

		private static bool SaveNoteList (ref NSString[] noteList)
		{
			NSError error = null;
			bool success = NSKeyedArchiver.ArchiveRootObjectToFile (NSArray.FromNSObjects (noteList), FilepathForNoteList);
			if (!success) {
				AppConnectLog.LogAtLevel (ACLogLevel.Error, "NSError: {0}", error);
			}
			return success;
		}

		private static bool SaveNote (NSString content, uint index)
		{
			string noteFilepath = FilepathForNoteIndex (index);
			NSData noteData = null;
			if (content == null) {
				noteData = new NSData ();
			} else {
				noteData = content.Encode (NSStringEncoding.UTF8);
			}
			NSError error = null;
			bool success = noteData.Save (noteFilepath, 0, out error);
			if (!success) {
				AppConnectLog.LogAtLevel (ACLogLevel.Error, "NSError: {0}", error);
			}
			return success;
		}

		// This method will ONLY remove the given note. NoteList will not be updated.
		private static void DeleteNote (uint index)
		{
			NSError error = null;
			string noteFilepath = FilepathForNoteIndex (index);
			NSFileManager.DefaultManager.Remove (noteFilepath, out error);
		}

		private static NSString titleForContent (NSString content)
		{
			if (content == null) {
				throw new Exception ("Content cannot be null.");
			}

			string localContent = content.ToString ().Trim ();
			int firstLineIndex = localContent.IndexOf (Environment.NewLine);
			string firstLine = null;

			if (firstLineIndex > 0) {
				firstLine = localContent.Substring (0, firstLineIndex);
			} else {
				firstLine = localContent;
			}

			if (firstLine.Length > 50) {
				firstLine = firstLine.Substring (0, 50);
			}

			return new NSString (firstLine);
		}

		private static string ApplicationSupportDirectoryPath {
			get {
				string[] applicationDocumentsDirs = NSSearchPath.GetDirectories (NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomain.User, true);
				string applicationDocumentsDir = applicationDocumentsDirs [0];
				string privateDocsDir = applicationDocumentsDir + "/NotesData";
				if (!NSFileManager.DefaultManager.FileExists (privateDocsDir)) {
					NSFileManager.DefaultManager.CreateDirectory (privateDocsDir, true, null);
				}
				return privateDocsDir;
			}
		}

		private static string FilepathForNoteList {
			get {
				return ApplicationSupportDirectoryPath + "/" + kNoteListFilename;
			}
		}

		private static string FilepathForNoteIndex (uint index)
		{
			return ApplicationSupportDirectoryPath + "/" + kNoteFilenameBase + "." + index;
		}
	}
}
