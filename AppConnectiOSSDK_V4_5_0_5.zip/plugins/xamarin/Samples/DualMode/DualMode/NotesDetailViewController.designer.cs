﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;

namespace DualMode
{
    [Register ("NotesDetailViewController")]
    partial class NotesDetailViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextView content { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (content != null) {
                content.Dispose ();
                content = null;
            }
        }
    }
}