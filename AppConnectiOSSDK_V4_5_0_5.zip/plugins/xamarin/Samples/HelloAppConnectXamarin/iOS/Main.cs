//-----------------------------------------------------------------------
// <copyright file="Main.cs" company="MobileIron">
//     Copyright (c) 2015 MobileIron. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using Foundation;
using UIKit;

namespace HelloAppConnectXamarin.iOS
{
	public class Application
	{
		// This is the main entry point of the application.
		static void Main (string[] args)
		{
			UIApplication.Main (args, AppConnectBinding.Constants.kACUIApplicationClassName, "HACAppDelegate");
		}
	}
}
