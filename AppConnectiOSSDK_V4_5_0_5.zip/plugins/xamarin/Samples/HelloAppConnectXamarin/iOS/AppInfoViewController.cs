//-----------------------------------------------------------------------
// <copyright file="AppInfoViewController.cs" company="MobileIron">
//     Copyright (c) 2015 MobileIron. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using Foundation;
using UIKit;

using AppConnectBinding;

namespace HelloAppConnectXamarin.iOS
{
	// Register this class in ObjC under the name used in original XIB to bloom the NIB file correctly.
	[Register ("AppInfoViewController")]
	public class AppInfoViewController : UIViewController
	{
		private bool AppConnectStopped = true;
		private HACAppDelegate hacAppDelegate = null;

		public AppInfoViewController (string nibName, NSBundle bundle) : base(nibName, bundle) {
			// Calling UIApplication.SharedApplication.Delegate will crash when AppConnect is started due to a known bug in Xamarin. 
			// Use AppConnectUIApplication.OriginalDelegate instead.
			this.hacAppDelegate = (HACAppDelegate)((AppConnectUIApplication)UIApplication.SharedApplication).OriginalDelegate;
			this.AppConnectStopped = false;
		}

		// @property (nonatomic, strong) IBOutlet UILabel *authSectionLabel;
		public UILabel authSectionLabel {
			[Export ("authSectionLabel")] get;
			[Export ("setAuthSectionLabel:")] set;
		}
		// @property (nonatomic, strong) IBOutlet UILabel *policySectionLabel;
		public UILabel policySectionLabel {
			[Export ("policySectionLabel")] get;
			[Export ("setPolicySectionLabel:")] set;
		}
		// @property (nonatomic, strong) IBOutlet UILabel *configSectionLabel;
		public UILabel configSectionLabel {
			[Export ("configSectionLabel")] get;
			[Export ("setConfigSectionLabel:")] set;
		}
		// @property (nonatomic, strong) IBOutlet UILabel *versionSectionLabel;
		public UILabel versionSectionLabel {
			[Export ("versionSectionLabel")] get;
			[Export ("setVersionSectionLabel:")] set;
		}

		// @property (nonatomic, strong) IBOutlet UITextView *authInfo;
		public UITextView authInfo {
			[Export ("authInfo")] get;
			[Export ("setAuthInfo:")] set;
		}
		// @property (nonatomic, strong) IBOutlet UITextView *policyInfo;
		public UITextView policyInfo {
			[Export ("policyInfo")] get;
			[Export ("setPolicyInfo:")] set;
		}
		// @property (nonatomic, strong) IBOutlet UITextView *configInfo;
		public UITextView configInfo {
			[Export ("configInfo")] get;
			[Export ("setConfigInfo:")] set;
		}
		// @property (nonatomic, strong) IBOutlet UITextView *versionInfo;
		public UITextView versionInfo {
			[Export ("versionInfo")] get;
			[Export ("setVersionInfo:")] set;
		}

		// @property (nonatomic, strong) IBOutlet UIScrollView *infoScrollView;
		public UIScrollView infoScrollView {
			[Export ("infoScrollView")] get;
			[Export ("setInfoScrollView:")] set;
		}

		// @property (nonatomic, strong) IBOutlet UIButton *stopRestartAppConnectButton;
		public UIButton stopRestartAppConnectButton {
			[Export ("stopRestartAppConnectButton")] get;
			[Export ("setStopRestartAppConnectButton:")] set;
		}

		// -(IBAction) displayMessageButtonTouchUpInside:(id)sender;
		[Export ("displayMessageButtonTouchUpInside:")]
		public void DisplayMessageButtonTouchUpInside(NSObject sender) {
			hacAppDelegate.DisplayMessage();
		}

		// -(IBAction) stopRestartAppConnect:(id)sender;
		[Export ("stopRestartAppConnect:")]
		public void StopRestartAppConnect(NSObject sender) {
			if (this.AppConnectStopped) {
				hacAppDelegate.RestartAppConnect ();
				this.AppConnectStopped = false;
				this.stopRestartAppConnectButton.SetTitle ("Stop AppConnect", UIControlState.Normal);
			} else {
				hacAppDelegate.StopAppConnect ();
				this.AppConnectStopped = true;
				this.stopRestartAppConnectButton.SetTitle ("Restart AppConnect", UIControlState.Normal);
			}
		}
	}
}
