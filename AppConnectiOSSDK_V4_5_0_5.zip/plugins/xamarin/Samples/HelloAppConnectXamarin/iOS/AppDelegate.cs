//-----------------------------------------------------------------------
// <copyright file="AppDelegate.cs" company="MobileIron">
//     Copyright (c) 2015 MobileIron. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Text;
using System.Collections.Generic;

using Foundation;
using UIKit;
using CoreGraphics;

using AppConnectBinding;

namespace HelloAppConnectXamarin.iOS
{
	public class HACAppConnectDelegate : AppConnectDelegate
	{
		private HACAppDelegate AppDelegate {
			get {
				return (HACAppDelegate)((AppConnectUIApplication)UIApplication.SharedApplication).OriginalDelegate;
			}
		}

		public override void AppConnectIsReady (AppConnect appConnect) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "AppConnectIsReady, ManagedPolicy=" + appConnect.ManagedPolicy + ", authState=" + appConnect.AuthState + ", authMessage=" + appConnect.AuthMessage);
			AppDelegate.UpdateLabels ();
		}

		public override void AuthStateChanged (AppConnect appConnect, ACAuthState newAuthState, string message) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "AuthStateChanged to: " + newAuthState, ", message = ", message);
			AppDelegate.UpdateLabels ();
		}

		public override void ConfigChanged(AppConnect appConnect, NSDictionary newConfig) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "ConfigChanged to: " + newConfig);
			AppDelegate.UpdateLabels ();
			appConnect.ConfigApplied(ACPolicyState.Applied, null);
		}

		public override void LogLevelChanged (AppConnect appConnect, ACLogLevel newLogLevel) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "LogLevelChanged to: " + newLogLevel);
			AppDelegate.UpdateLabels ();
		}

		public override void ManagedPolicyChanged (AppConnect appConnect, ACManagedPolicy newManagedPolicy) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "ManagedPolicyChanged to: " + newManagedPolicy);
			AppDelegate.UpdateLabels ();
		}

		public override void OpenInPolicyChanged (AppConnect appConnect, ACOpenInPolicy newOpenInPolicy, NSSet newWhitelist) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "OpenInPolicyChanged to: " + newOpenInPolicy + ", newWhitelist = " + newWhitelist);
			AppDelegate.UpdateLabels ();
			appConnect.OpenInPolicyApplied (ACPolicyState.Applied, null);
		}

		public override void PasteboardPolicyChanged (AppConnect appConnect, ACPasteboardPolicy newPasteboardPolicy) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "PasteboardPolicyChanged to: " + newPasteboardPolicy);
			AppDelegate.UpdateLabels ();
			appConnect.PasteboardPolicyApplied (ACPolicyState.Applied, null);
		}

		public override void PrintPolicyChanged (AppConnect appConnect, ACPrintPolicy newPrintPolicy) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "PrintPolicyChanged to: " + newPrintPolicy);
			AppDelegate.UpdateLabels ();
			appConnect.PrintPolicyApplied (ACPolicyState.Applied, null);
		}

		public override void SecureFileIOPolicyChanged (AppConnect appConnect, ACSecureFileIOPolicy newSecureFileIOPolicy) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "SecureFileIOPolicyChanged to: " + newSecureFileIOPolicy);
			AppDelegate.UpdateLabels ();
			appConnect.SecureFileIOPolicyApplied (ACPolicyState.Applied, null);
		}

		public override void SecureServicesAvailabilityChanged (AppConnect appConnect, ACSecureServicesAvailability secureServicesAvailability) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "SecureServicesAvailabilityChanged to: " + secureServicesAvailability);
			AppDelegate.UpdateLabels ();
		}

		public override void ApplicationWillResignActive (AppConnect appConnect) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "Application is resigning active because of AppConnect (ie, flip to MIClient or TouchID)");
		}

		public override void ApplicationDidBecomeActive (AppConnect appConnect) {
			AppConnectLog.LogAtLevel(ACLogLevel.Info, "Application is becoming active because of AppConnect (ie, flip from MIClient or TouchID)");
		}
	}

	[Register ("HACAppDelegate")]
	public partial class HACAppDelegate : UIApplicationDelegate
	{
		UIWindow window = null;
		AppConnect appConnect = null;
		AppInfoViewController appInfoViewController = null;
		AppConnectDelegate appConnectDelegate = null;

		// - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
		public override bool FinishedLaunching (UIApplication application, NSDictionary options)
		{
			AppConnectLog.LogAtLevel (ACLogLevel.Status, "HelloAppConnect started on {0}", DateTime.Now);

			this.window = new UIWindow (UIScreen.MainScreen.Bounds);
			this.appInfoViewController = new AppInfoViewController ("AppInfoViewController", null);
			window.RootViewController = this.appInfoViewController;
			window.MakeKeyAndVisible ();

			this.appConnectDelegate = new HACAppConnectDelegate ();
			AppConnect.InitWithDelegate (this.appConnectDelegate);
			this.appConnect = AppConnect.SharedInstance;
			AppConnectLog.LogAtLevel (ACLogLevel.Status, "SDK Version = " + AppConnect.Version);
			AppConnectLog.LogAtLevel (ACLogLevel.Status, "appConnect = " + this.appConnect);
			AppConnectLog.LogAtLevel (ACLogLevel.Status, "isReady = " + this.appConnect.Ready);
			if (this.appConnect != null) {
				this.appConnect.StartWithLaunchOptions (options);
			}
			this.appInfoViewController.infoScrollView.ContentSize = new CGSize(320, 1000);

			UpdateLabels ();

			return true;
		}

		// - (void)applicationDidBecomeActive:(UIApplication *)application
		public override void OnActivated (UIApplication application) {
			UpdateLabels ();
		}

		public void UpdateLabels () {
			string authInfoText = null;
			string policyInfoText = null;
			string configInfoText = null;

			if (this.appConnect.Ready) {
				authInfoText = AuthInfoText ();
				policyInfoText = PolicyInfoText ();
				configInfoText = ConfigInfoText ();
			} else {
				authInfoText = "Ready: NO (AppConnect is not ready yet)";
				policyInfoText = "AppConnect is not ready yet";
				configInfoText = "AppConnect is not ready yet";
			}

			this.appInfoViewController.authInfo.Text = authInfoText;
			this.appInfoViewController.policyInfo.Text = policyInfoText;
			this.appInfoViewController.configInfo.Text = configInfoText;

			string versionInfoText = "AppConnect Version: " + AppConnect.Version;
			this.appInfoViewController.versionInfo.Text = versionInfoText;

			// Auth position is fixed. Other labels need to be positioned once text
			// content changes which could change the size of the text views.
			// Set auth text position
			CGRect rect = this.appInfoViewController.authInfo.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.authSectionLabel.Frame.Y + this.appInfoViewController.authSectionLabel.Frame.Height + 4);
			// adjust text view size to fit entire text
			rect.Height = this.appInfoViewController.authInfo.ContentSize.Height;
			this.appInfoViewController.authInfo.Frame = rect;

			// Set policy section label position
			rect = this.appInfoViewController.policySectionLabel.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.authInfo.Frame.Y + this.appInfoViewController.authInfo.Frame.Height + 4);
			this.appInfoViewController.policySectionLabel.Frame = rect;
			// Set policy text position
			rect = this.appInfoViewController.policyInfo.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.policySectionLabel.Frame.Y + this.appInfoViewController.policySectionLabel.Frame.Height + 4);
			// adjust text view size to fit entire text
			rect.Height = this.appInfoViewController.policyInfo.ContentSize.Height;
			this.appInfoViewController.policyInfo.Frame = rect;

			// Set Config section label position
			rect = this.appInfoViewController.configSectionLabel.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.policyInfo.Frame.Y + this.appInfoViewController.policyInfo.Frame.Height + 4);
			this.appInfoViewController.configSectionLabel.Frame = rect;
			// Set Config section text position
			rect = this.appInfoViewController.configInfo.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.configSectionLabel.Frame.Y + this.appInfoViewController.configSectionLabel.Frame.Height + 5);
			// adjust text view size to fit entire text
			rect.Height = this.appInfoViewController.configInfo.ContentSize.Height;
			this.appInfoViewController.configInfo.Frame = rect;

			// Set Version section label position
			rect = this.appInfoViewController.versionSectionLabel.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.configInfo.Frame.Y + this.appInfoViewController.configInfo.Frame.Height + 4);
			this.appInfoViewController.versionSectionLabel.Frame = rect;
			// Set Version section text position
			rect = this.appInfoViewController.versionInfo.Frame;
			rect.Location = new CGPoint(0, this.appInfoViewController.versionSectionLabel.Frame.Y + this.appInfoViewController.versionSectionLabel.Frame.Height + 5);
			// adjust text view size to fit entire text
			rect.Height = this.appInfoViewController.versionInfo.ContentSize.Height;
			this.appInfoViewController.versionInfo.Frame = rect;

			nfloat contentHeight =
				this.appInfoViewController.authSectionLabel.Frame.Height +
				this.appInfoViewController.authInfo.Frame.Height +
				this.appInfoViewController.policySectionLabel.Frame.Height +
				this.appInfoViewController.policyInfo.Frame.Height +
				this.appInfoViewController.configSectionLabel.Frame.Height +
				this.appInfoViewController.configInfo.Frame.Height +
				this.appInfoViewController.versionSectionLabel.Frame.Height +
				this.appInfoViewController.versionInfo.Frame.Height + 40;

			// Adjust the scroll view content size
			this.appInfoViewController.infoScrollView.ContentSize = new CGSize(320, contentHeight);
		}

		public void DisplayMessage () {
			if (this.appConnect != null) {
				this.appConnect.DisplayMessage (this.appConnect.AuthMessage);
			}
		}

		public void StopAppConnect () {
			AppConnectLog.LogAtLevel (ACLogLevel.Status, "HelloAppConnect stopping...");
			if (this.appConnect != null) {
				this.appConnect.Retire ();
				this.appConnect.Stop ();
			}
			UpdateLabels ();
		}

		public void RestartAppConnect () {
			AppConnectLog.LogAtLevel (ACLogLevel.Status, "HelloAppConnect restarting...");
			AppConnect.InitWithDelegate (this.appConnectDelegate);
			this.appConnect = AppConnect.SharedInstance;
			if (this.appConnect != null) {
				this.appConnect.StartWithLaunchOptions (null);
			}
		}

		private string AuthInfoText () {
			string authInfoText = "Ready: " + (this.appConnect.Ready ? "YES": "NO");

			switch (this.appConnect.ManagedPolicy) {
			case ACManagedPolicy.Unmanaged:
					authInfoText += "\nManaged: Unmanaged";
					break;
				case ACManagedPolicy.Managed:
					authInfoText += "\nManaged: Managed";
					break;
				case ACManagedPolicy.Unknown:
				default:
					authInfoText += "\nManaged: Unknown";
					break;
			}

			switch (this.appConnect.AuthState) {
				case ACAuthState.Unauthorized:
					authInfoText += "\nAuth State: Unauthorized";
					break;
				case ACAuthState.Authorized:
					authInfoText += "\nAuth State: Authorized";
					break;
				case ACAuthState.Retired:
					authInfoText += "\nAuth State: Retired";
					break;
				default:
					authInfoText += "\nAuth State: Unknown";
					break;
			}

			authInfoText += "\nAuth Message: " + this.appConnect.AuthMessage;

			// Secure services availability
			switch (this.appConnect.SecureServicesAvailability) {
			case ACSecureServicesAvailability.Available:
				string appKeyString = null;
				string sharedKeyString = null;
				{
					var index = "index";
					// keys are 256-bit
					var appKey = new byte[32];
					var sharedKey = new byte[32];

					NSError error = null;
					error = this.appConnect.DerivedAppKey (ref appKey, index);
					if (error != null) {
						appKeyString = error.LocalizedDescription;
					} else {
						appKeyString = BitConverter.ToString (appKey);
					}

					error = this.appConnect.DerivedSharedKey (ref sharedKey, index);
					if (error != null) {
						sharedKeyString = error.LocalizedDescription;
					} else {
						sharedKeyString = BitConverter.ToString (sharedKey);
					}
				}
				authInfoText += "\nSecure Services: Available";
				authInfoText += "\nDerived App Key: " + appKeyString;
				authInfoText += "\nDerived Shared Key: " + sharedKeyString;
				break;
			case ACSecureServicesAvailability.Unavailable:
				authInfoText += "\nSecure Services: Unavailable";
				break;
			default:
				authInfoText += "\nSecure Services: Unknown";
				break;
			}

			return authInfoText;
		}

		private string PolicyInfoText () {
			string policyInfoText = "";

			// Pasteboard
			switch (this.appConnect.PasteboardPolicy) {
			case ACPasteboardPolicy.Unauthorized:
				policyInfoText += "Pasteboard: Unauthorized\n";
				break;
			case ACPasteboardPolicy.Authorized:
				policyInfoText += "Pasteboard: Authorized\n";
				break;
			case ACPasteboardPolicy.SecureCopy:
				policyInfoText += "Pasteboard: Secure Copy (AppConnect Apps)\n";
				break;
			default:
				policyInfoText += "Pasteboard: Policy Unknown\n";
				break;
			}

			// OpenIn
			switch (this.appConnect.OpenInPolicy) {
			case ACOpenInPolicy.Unauthorized:
				policyInfoText += "Open In: Unauthorized\n";
				break;
			case ACOpenInPolicy.Authorized:
				policyInfoText += "Open In: Authorized for all apps\n";
				break;
			case ACOpenInPolicy.Whitelist: {
					string whitelistEntries = null;
					if (0 == this.appConnect.OpenInWhitelist.Count) {
						whitelistEntries = "(none)\n";
					} else {
						whitelistEntries = "\n";
						foreach (NSString entry in this.appConnect.OpenInWhitelist) {
							whitelistEntries += "   " + entry + "\n";
						}
					}
					policyInfoText += "Open In: Authorized for whitelist: " + whitelistEntries;
					break;
				}
			default:
				policyInfoText += "Open In: Policy Unknown\n";
				break;
			}

			// Print
			switch (this.appConnect.PrintPolicy) {
			case ACPrintPolicy.Authorized:
				policyInfoText += "Print: Authorized\n";
				break;
			case ACPrintPolicy.Unauthorized:
				policyInfoText += "Print: Unauthorized\n";
				break;
			default:
				policyInfoText += "Print: Policy Unknown\n";
				break;
			}

			// Secure File IO
			switch (this.appConnect.SecureFileIOPolicy) {
			case ACSecureFileIOPolicy.Optional:
				policyInfoText += "Secure File IO: Optional\n";
				break;
			case ACSecureFileIOPolicy.Required:
				policyInfoText += "Secure File IO: Required\n";
				break;
			default:
				policyInfoText += "Secure File IO: Policy Unknown\n";
				break;
			}

			// Log level
			switch (AppConnectLog.LogLevel) {
			case ACLogLevel.Status:
				policyInfoText += "Log Level: Status";
				break;
			case ACLogLevel.Warning:
				policyInfoText += "Log Level: Warning";
				break;
			case ACLogLevel.Error:
				policyInfoText += "Log Level: Error";
				break;
			case ACLogLevel.Info:
				policyInfoText += "Log Level: Info";
				break;
			case ACLogLevel.Verbose:
				policyInfoText += "Log Level: Verbose";
				break;
			case ACLogLevel.Debug:
				policyInfoText += "Log Level: Debug";
				break;
			default:
				policyInfoText += "Log Level: Unknown";
				break;
			}

			return policyInfoText;
		}

		private string ConfigInfoText () {
			string configInfoText = "";
			if (this.appConnect.Config != null) {
				configInfoText += "Configuration: {\n";
				foreach (KeyValuePair<NSObject, NSObject> pair in this.appConnect.Config) {
					configInfoText += "\t" + pair.Key + " = " + pair.Value + "\n";
				}
				configInfoText += "}";
			} else {
				configInfoText = "Configuration:\n(none)";
			}
			return configInfoText;
		}
	}
}
