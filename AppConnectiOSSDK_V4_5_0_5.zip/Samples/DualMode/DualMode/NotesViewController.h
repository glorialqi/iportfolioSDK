//
//  NotesViewController.h
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  View controller for showing the list of notes.
//

#import <UIKit/UIKit.h>
#import "NotesDetailViewController.h"

@interface NotesViewController : UITableViewController <UISplitViewControllerDelegate, NotesDetailDelegate>

- (IBAction)addNewNote;
- (void)refreshUI;

@end
