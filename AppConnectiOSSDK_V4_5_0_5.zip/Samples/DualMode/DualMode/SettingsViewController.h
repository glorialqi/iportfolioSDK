//
//  SettingsViewController.h
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  View controller that tells the user whether the app is currently managed by MobileIron,
//  and provides a way for the user to switch management on or off.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UITableViewController

@property (nonatomic, strong) IBOutlet UISwitch *miMode;

-(IBAction)switchMode:(id)sender;

@end
