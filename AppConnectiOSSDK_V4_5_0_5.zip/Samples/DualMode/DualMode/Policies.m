//
//  Policies.m
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  Singleton that implements the core dual mode behavior. It tracks an overall
//  state, manages transitions between them, and provides a single source of
//  current policies for other classes. It is also responsible for starting and
//  stopping AppConnect, and it provides the AppConnectDelegate
//

#import "Policies.h"
#import <AppConnect/AppConnect.h>
#import "DualModeAppDelegate.h"
#import "Notes.h"

NSString * dualModeStateString(DualModeState state) {
    switch (state) {
        case DMS_Undecided:
            return @"DMS_Undecided";
        case DMS_NonACMode:
            return @"DMS_NonACMode";
        case DMS_ACMode:
            return @"DMS_ACMode";
        case DMS_ACNotAvailable:
            return @"DMS_ACNotAvailable";
        case DMS_PendingACMode:
            return @"DMS_PendingACMode";
    }
}

static NSString * const kDualModeStateDefaultsKey = @"DualModeState";
static NSString * const kEncryptedStateDefaultsKey = @"EncryptedState";
static Policies * _sharedInstance = nil;

@interface Policies () {
    DualModeState _state;
    BOOL _dataEncrypted;
    AppConnect *_ac;
}

@property (nonatomic, assign) BOOL dataEncrypted;
@property (nonatomic, strong) AppConnect *ac;

@end

@implementation Policies
@synthesize state = _state;
@synthesize ac = _ac;

+(void)initWithLaunchOptions:(NSDictionary *)launchOptions {
    if ( _sharedInstance ) {
        [NSException raise:@"Logic error in call to Policies method +initWithLaunchOptions:" format:@"Method must be called only once"];
    }
    _sharedInstance = [[Policies alloc] initPrivateWithLaunchOptions:launchOptions];
}

+(Policies *)sharedInstance {
    // NOTE:: Call +intWithLaunchOptions: to allocate the shared instance.
    return _sharedInstance;
}

-(id)init {
    [NSException raise:@"Logic error in call to Policies method -init" format:@"Must call +initWithLaunchOptions: then +sharedInstance instead"];
    return nil;
}

-(id)initPrivateWithLaunchOptions:(NSDictionary *)launchOptions {
    self = [super init];
    if (self) {
        // Custom initialization
        
        // Restore dual mode state
        NSInteger storedDualModeState = [[NSUserDefaults standardUserDefaults] integerForKey:kDualModeStateDefaultsKey];
        // Validate stored state in case app was upgraded
        if ( storedDualModeState < DMS_First || DMS_Last < storedDualModeState ) {
            // Unknown value. Discard it.
            storedDualModeState = DMS_Undecided;
        }
        _state = storedDualModeState;

        // Restore encryption state
        NSInteger storedEncryptionState = [[NSUserDefaults standardUserDefaults] integerForKey:kEncryptedStateDefaultsKey];
        _dataEncrypted = !!storedEncryptionState;
        
        _ac = nil;
        // If current _state is NOT DMS_NonACMode
        // And if AppConnect is available for this app
        // Start the AppConnect SDK with delegate. Else, start in stand alone mode.
        [AppConnect logAtLevel:ACLogLevelInfo format:@"Checking for App Connect availability."];
        if (DMS_NonACMode != _state && [AppConnect shouldStartAppConnect]) {
            [AppConnect logAtLevel:ACLogLevelInfo format:@"App Connect is Available."];
            [AppConnect initWithDelegate:self];
            _ac = [AppConnect sharedInstance];
            [_ac startWithLaunchOptions:launchOptions];
        }
        else if (DMS_Undecided == _state) {
            [self setState:DMS_ACNotAvailable];
        }
    }
    
    return self;
}

-(void)switchToNonACMode {
    if (!(DMS_ACMode == _state || DMS_PendingACMode == _state)) {
        [NSException raise:@"Logic error in call to Policies method -switchToNonACMode" format:@"state must be DMS_ACMode or DMS_PendingACMode"];
    }
    
    [AppConnect logAtLevel:ACLogLevelStatus format:@"Switched to non-AppConnect mode."];
    [Notes removeData];
    [self setDataEncrypted:NO];
    [self setState:DMS_NonACMode];
    [_ac retire];
    [_ac stop];
    _ac = nil;
    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate nonAcModeChangeCompleted];
}

-(void)attemptSwitchToACMode {
    if ( DMS_PendingACMode == _state) {
        // Already have a pending switch to App-Connect mode
        return;
    }
    if ( DMS_NonACMode != _state ) {
        [NSException raise:@"Logic error in call to Policies method -attemptSwitchToACMode" format:@"state must be DMS_NonACMode"];
    }

    [AppConnect logAtLevel:ACLogLevelStatus format:@"Attempting to switch to AppConnect mode."];
    
    [self setState:DMS_PendingACMode];
    [AppConnect initWithDelegate:self];
    _ac = [AppConnect sharedInstance];
    [_ac startWithLaunchOptions:nil];
}

-(BOOL)useSecureFileIO {
    return _dataEncrypted;
}

-(BOOL)allowCopy {
    switch (_state) {
        case DMS_Undecided:
        case DMS_NonACMode:
        case DMS_PendingACMode:
        case DMS_ACNotAvailable:
            return YES;
        case DMS_ACMode:
            return ACPasteboardPolicyAuthorized == [_ac pasteboardPolicy] ||
                    ACPasteboardPolicySecureCopy == [_ac pasteboardPolicy];
    }
}

-(BOOL)displayAuthMessage:(NSString**)authMessage {
    *authMessage = nil;
    switch (_state) {
        case DMS_Undecided:
            *authMessage = @"Determining mode";
            return YES;
        case DMS_NonACMode:
        case DMS_PendingACMode:
        case DMS_ACNotAvailable:
            return NO;
        case DMS_ACMode:
            if (![_ac isReady]) {
                *authMessage = @"AppConnect is not ready yet";
                return YES;
            }

            switch ([_ac authState]) {
                case ACAuthStateAuthorized:
                    return NO;
                case ACAuthStateUnauthorized:
                    *authMessage = [@"You are not currently authorized to use this app for the following reason(s):\n\n" stringByAppendingString:[_ac authMessage]];
                    return YES;
                case ACAuthStateRetired:
                    *authMessage = [@"You are not currently authorized to use this app, and your notes have been deleted, for the following reason(s):\n\n" stringByAppendingString:[_ac authMessage]];
                    return YES;
            }
    }
}

-(BOOL)notesAvailable {
    switch (_state) {
        case DMS_Undecided:
            return NO;
        case DMS_NonACMode:
        case DMS_ACNotAvailable:
            return YES;
        case DMS_PendingACMode:
            return NO;
        case DMS_ACMode: {
            return [_ac isReady] && (!_dataEncrypted || ACSecureServicesAvailabilityAvailable == [_ac secureServicesAvailability]);
        }
    }
}

#pragma mark -
#pragma mark Private methods
-(void) setState:(DualModeState)state {
    [AppConnect logAtLevel:ACLogLevelStatus format:@"Current App State: %@", dualModeStateString(_state)];
    _state = state;
    [[NSUserDefaults standardUserDefaults] setInteger:state forKey:kDualModeStateDefaultsKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self checkEncryptionState];
    [AppConnect logAtLevel:ACLogLevelStatus format:@"Updated App State: %@", dualModeStateString(_state)];
}

-(void) setDataEncrypted:(BOOL)dataEncrypted {
    _dataEncrypted = dataEncrypted;
    [[NSUserDefaults standardUserDefaults] setInteger:dataEncrypted forKey:kEncryptedStateDefaultsKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

-(void) checkEncryptionState {
    if (![_ac isReady]) {
        return;
    }
    
    // If:
    //     app is in AppConnect Mode, and
    //     encryption is required, and
    //     data is not currently encrypted, and
    //     secure services are currently available
    if (DMS_ACMode == _state &&
        ACSecureFileIOPolicyRequired == [_ac secureFileIOPolicy] &&
        !_dataEncrypted &&
        ACSecureServicesAvailabilityAvailable == [_ac secureServicesAvailability] ) {

        // Encrypt all data
        [Notes encryptAllData];
        [self setDataEncrypted:YES];
        return;

    }
}

#pragma mark -
#pragma mark AppConnectDelegate methods
-(void)appConnectIsReady:(AppConnect *)appConnect {
    [AppConnect logAtLevel:ACLogLevelStatus format:@"%s", __FUNCTION__];
    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate refreshUI];
}

-(void) appConnect:(AppConnect *)appConnect authStateChangedTo:(ACAuthState)newAuthState withMessage:(NSString *)message {
    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
    [AppConnect logAtLevel:ACLogLevelStatus format:@"%s: Current App State: %@", __FUNCTION__, dualModeStateString(_state)];
    switch (_state) {
        case DMS_Undecided:
        case DMS_NonACMode:
        case DMS_PendingACMode:
        case DMS_ACNotAvailable:
            // Nothing to do
            break;
        case DMS_ACMode:
            if ( ACAuthStateRetired == newAuthState ) {
                [Notes removeData];
            }
            // Ensure that the UI is updated to display, dismiss, or update the auth message.
            [appDelegate refreshUI];
            break;
    }
    [appConnect authStateApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect managedPolicyChangedTo:(ACManagedPolicy)newManagedPolicy {
    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
    [AppConnect logAtLevel:ACLogLevelStatus format:@"%s: Current App State: %@", __FUNCTION__, dualModeStateString(_state)];
    switch (_state) {
        case DMS_Undecided:
        case DMS_ACNotAvailable:
            // Initial mode selected
            switch (newManagedPolicy) {
                case ACManagedPolicyUnknown:
                    // Nothing to do yet.
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"New managed policy ACMANAGEDPOLICY_UNKNOWN. Nothing to do."];
                    break;
                case ACManagedPolicyUnmanaged: {
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"New managed policy ACMANAGEDPOLICY_UNMANAGED."];
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"App entering non-AppConnect mode."];
                    [_ac retire];
                    [_ac stop];
                    _ac = nil;
                    [self setState:DMS_NonACMode];
                    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
                    [appDelegate refreshUI];
                    break;
                }
                case ACManagedPolicyManaged: {
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"New managed policy ACMANAGEDPOLICY_MANAGED."];
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"App entering AppConnect mode."];
                    [self setState:DMS_ACMode];
                    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
                    [appDelegate refreshUI];
                    break;
                }
            }
            break;

        case DMS_NonACMode:
        case DMS_ACMode:
            // Nothing to do
            break;

        case DMS_PendingACMode:
            // Attempt to change to AC Mode
            switch (newManagedPolicy) {
                case ACManagedPolicyUnknown:
                    // Nothing to do yet.
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"New managed policy ACMANAGEDPOLICY_UNKNOWN. Nothing to do."];
                    break;
                case ACManagedPolicyUnmanaged: {
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"New managed policy ACMANAGEDPOLICY_UNMANAGED."];
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"Switch to AppConnect mode failed."];
                    [self setState:DMS_NonACMode];
                    NSString *acAuthMessage = [_ac isReady] ? [_ac authMessage] : @"This app is not managed.";
                    [_ac retire];
                    [_ac stop];
                    _ac = nil;
                    DualModeAppDelegate *appDelegate = (DualModeAppDelegate *)[[UIApplication sharedApplication] delegate];
                    [appDelegate acModeChangeCompleted:NO withReason:acAuthMessage];
                    break;
                }
                case ACManagedPolicyManaged:
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"New managed policy ACMANAGEDPOLICY_MANAGED."];
                    [AppConnect logAtLevel:ACLogLevelStatus format:@"Switch to AppConnect mode succeeded."];
                    [self setState:DMS_ACMode];
                    if ( ACAuthStateRetired == [_ac authState] ) {
                        [Notes removeData];
                    }
                    [appDelegate acModeChangeCompleted:YES withReason:nil];
                    break;
            }
            break;
    }
}

-(void)appConnect:(AppConnect *)appConnect secureServicesAvailabilityChangedTo:(ACSecureServicesAvailability)secureServicesAvailability {
    [AppConnect logAtLevel:ACLogLevelStatus format:@"Secure Services Availability Changed To %ld", (long)secureServicesAvailability];
    [self checkEncryptionState];
}


-(void) appConnect:(AppConnect *)appConnect pasteboardPolicyChangedTo:(ACPasteboardPolicy)newPasteboardPolicy {
    [AppConnect logAtLevel:ACLogLevelStatus format:@"Pasteboard Policy Changed To %ld", (long)newPasteboardPolicy];
    /*
     An app that has user interfaces for copying to the pasteboard would enable or disable the interfaces based on the policy.
     */
    [_ac pasteboardPolicyApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect secureFileIOPolicyChangedTo:(ACSecureFileIOPolicy)newSecureFileIOPolicy {
    [AppConnect logAtLevel:ACLogLevelStatus format:@"Secure File IO Policy Changed To %ld", (long)newSecureFileIOPolicy];
    [self checkEncryptionState];
    [_ac secureFileIOPolicyApplied:ACPolicyStateApplied message:nil];
}

@end
