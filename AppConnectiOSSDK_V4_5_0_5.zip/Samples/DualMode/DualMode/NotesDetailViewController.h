//
//  NotesDetailViewController.h
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  View controller for showing and editing the content of an individual note.
//

#import <UIKit/UIKit.h>

@class NotesDetailViewController;

@protocol NotesDetailDelegate <NSObject>

- (void)notesDetailViewController:(NotesDetailViewController *)notesDetailVC didUpdateNoteAtIndex:(NSInteger)noteIndex withText:(NSString *)noteText;

@end


@interface NotesDetailViewController : UIViewController <UITextViewDelegate>

@property (nonatomic, strong) IBOutlet UITextView *content;
@property (nonatomic, weak) id<NotesDetailDelegate> delegate;
@property (nonatomic, assign) NSInteger noteIndex;

- (void)reset;

@end
