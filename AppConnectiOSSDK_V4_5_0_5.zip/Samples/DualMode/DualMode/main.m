//
//  main.m
//  ACSampleAppDualMode
//
//  Copyright (c) 2013 MobileIron. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DualModeAppDelegate.h"
#import <AppConnect/AppConnect.h>

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, kACUIApplicationClassName, NSStringFromClass([DualModeAppDelegate class]));
    }
}
