//
//  AuthMessageViewController.h
//  DualMode
//
//  Copyright (c) 2013 MobileIron. All rights reserved.
//
//  Controller for view that shows the AppConnect authMessage when the app is not authorized
//

#import <UIKit/UIKit.h>

@interface AuthMessageViewController : UIViewController
@property (nonatomic, strong) NSString *messageText;
@property (nonatomic, strong) IBOutlet UILabel *authMessage;

@end
