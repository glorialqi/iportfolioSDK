//
//  ACDualModeAppDelegate.h
//  ACSampleAppDualMode
//
//  Copyright (c) 2013 MobileIron. All rights reserved.
//
//  UIApplicationDelegate for the app. Coordinates between model classes (Notes, Policies)
//  and various view classes.
//

#import <UIKit/UIKit.h>
#import "Policies.h"

@interface DualModeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

-(void)acModeChangeCompleted:(BOOL)success withReason:(NSString*)reason;
-(void)nonAcModeChangeCompleted;
-(void)refreshUI;

@end
