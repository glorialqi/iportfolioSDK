//
//  SettingsViewController.m
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  View controller that tells the user whether the app is currently managed by MobileIron,
//  and provides a way for the user to switch management on or off.
//

#import "SettingsViewController.h"
#import "Policies.h"
#import "DualModeAppDelegate.h"

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.navigationController.navigationBar.topItem.leftBarButtonItem == nil) {
        UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                                                    target:self
                                                                                    action:@selector(done:)];
        self.navigationItem.leftItemsSupplementBackButton = YES;
        self.navigationItem.leftBarButtonItem = doneButton;
    }
    
    self.title = @"Settings";
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    // miMode switch should be enabled only if AppConnect is Available. If it is not available, we should not allow user
    // to enter Appconnect mode.
    [self.miMode setEnabled:[AppConnect shouldStartAppConnect]];
    [self.miMode setOn:(DMS_ACMode == [[Policies sharedInstance] state] || DMS_PendingACMode == [[Policies sharedInstance] state])];
}

#pragma mark -
#pragma IBAction methods

-(IBAction)switchMode:(id)sender {
    if (sender == self.miMode) {
        BOOL isMIModeTurnedOn = [self.miMode isOn];
        NSString *alertTitle = @"MobileIron Management";
        NSString *alertMessage = isMIModeTurnedOn ? @"This app will attempt to be secured and managed by MobileIron. "
                                                    "Tap OK to continue. Tap Cancel to keep this app unsecured and unmanaged." :
                                                    @"This app will no longer be managed by MobileIron. "
                                                    "All your notes will be permanently erased. Tap OK to continue. "
                                                    "Tap Cancel to keep your notes and keep this app managed by MobileIron.";
        UIAlertController *modeAlert = [UIAlertController alertControllerWithTitle:alertTitle
                                                                           message:alertMessage
                                                                    preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction * _Nonnull action) {
                                                             
                                                             
            void (^policySwitchBlock)(void) = ^{
                if (isMIModeTurnedOn) {
                    [[Policies sharedInstance] attemptSwitchToACMode];
                }
                else {
                    [[Policies sharedInstance] switchToNonACMode];
                }
            };
                                                             
            if ([self presentingViewController]) {
                [self dismissViewControllerAnimated:NO completion:policySwitchBlock];
            }
            else {
                [[self navigationController] popToRootViewControllerAnimated:NO];
                policySwitchBlock();
            }
        }];

        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel"
                                                               style:UIAlertActionStyleCancel
                                                             handler:^(UIAlertAction * _Nonnull action) {
            [self.miMode setOn:!isMIModeTurnedOn];
        }];
        
        [modeAlert addAction:okAction];
        [modeAlert addAction:cancelAction];

        [self presentViewController:modeAlert animated:YES completion:nil];
    }
}

-(IBAction)done:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
