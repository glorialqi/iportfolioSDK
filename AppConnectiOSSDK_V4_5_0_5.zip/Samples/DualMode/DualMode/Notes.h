//
//  Notes.h
//  DualMode
//
//  Copyright (c) 2013 MobileIron. All rights reserved.
//
//  Data model for storing a list of notes and the content of those notes.
//  Notes are optionally encrypted using AppConnect Secure File IO.
//

#import <Foundation/Foundation.h>
#import "Policies.h"

@interface Notes : NSObject

+(NSError *)getNoteList:(NSArray **)pNoteList;
+(NSError *)getContent:(NSString **)pNoteContent atIndex:(int)noteIndex;
+(NSError *)addNote;
+(NSError *)setContent:(NSString *)content atIndex:(int)noteIndex;
+(void)removeData;
+(void)encryptAllData;

@end
