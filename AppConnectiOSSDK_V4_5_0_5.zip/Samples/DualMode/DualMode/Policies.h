//
//  Policies.h
//  DualMode
//
//  Copyright (c) 2013 MobileIron. All rights reserved.
//
//  Singleton that implements the core dual mode behavior. It tracks an overall
//  state, manages transitions between them, and provides a single source of
//  current policies for other classes. It is also responsible for starting and
//  stopping AppConnect, and it provides the AppConnectDelegate
// 

#import <Foundation/Foundation.h>
#import <AppConnect/AppConnect.h>

typedef NS_ENUM(NSInteger, DualModeState) {
    DMS_First = 0,
    DMS_Undecided = DMS_First, // App has not yet selected a mode. Awaiting -appConnect:managedPolicyChangedTo: to select a mode.
    DMS_NonACMode,                 // App is in non-AppConnect mode
    DMS_ACMode,                    // App is in AppConnect mode
    DMS_PendingACMode,             // User requested AC mode. Awaiting -appConnect:managedPolicyChangedTo: before allowing the mode change.
    DMS_ACNotAvailable, // App Connect is unavailable for now.
    DMS_Last = DMS_ACNotAvailable,
};

@interface Policies : NSObject <AppConnectDelegate>

@property (nonatomic, readonly) DualModeState state;

+(void)initWithLaunchOptions:(NSDictionary *)launchOptions;
+(Policies *)sharedInstance;
-(void)switchToNonACMode;
-(void)attemptSwitchToACMode;
-(BOOL)useSecureFileIO;
-(BOOL)allowCopy;
-(BOOL)displayAuthMessage:(NSString**)authMessage;
-(BOOL)notesAvailable;

@end
