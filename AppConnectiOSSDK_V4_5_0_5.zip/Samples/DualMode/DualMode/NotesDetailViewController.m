//
//  NotesDetailViewController.m
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  View controller for showing and editing the content of an individual note.
//

#import "NotesDetailViewController.h"
#import "Notes.h"

@implementation NotesDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _noteIndex = -1;
    }
    return self;
}

- (id)initWithCoder:(NSCoder*)aDecoder {
    if(self = [super initWithCoder:aDecoder]) {
        NSArray *notes;
        NSError *error = [Notes getNoteList:&notes];
        _noteIndex = (!error && ([notes count] > 0)) ? 0 : -1;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.content.delegate = self;
    [self configureContent];
    self.splitViewController.displayModeButtonItem.title = @"Notes";
    self.title = @"Details";
    self.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
    self.navigationItem.leftItemsSupplementBackButton = YES;
}

- (void)configureContent {
    NSString *noteText = @"";
    if (0 <= self.noteIndex) {
        [Notes getContent:&noteText atIndex:(int)self.noteIndex];
    }
    self.content.text = noteText;
}

#pragma mark - UITextViewDelegate methods
- (void)textViewDidEndEditing:(UITextView *)textView {
    if ([self.delegate respondsToSelector:@selector(notesDetailViewController:didUpdateNoteAtIndex:withText:)]) {
        [self.delegate notesDetailViewController:self didUpdateNoteAtIndex:self.noteIndex withText:textView.text];
    }
}

#pragma mark - Public methods
-(void)reset {
    self.noteIndex = -1;
    [self configureContent];
}

@end
