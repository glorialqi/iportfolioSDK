//
//  AuthMessageViewController.m
//  DualMode
//
//  Copyright (c) 2013 MobileIron. All rights reserved.
//
//  Controller for view that shows the AppConnect authMessage when the app is not authorized
//

#import "AuthMessageViewController.h"

@interface AuthMessageViewController ()

@end

@implementation AuthMessageViewController
@synthesize messageText=_messageText;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.authMessage.text = self.messageText;
}

-(void)setMessageText:(NSString *)messageText {
    _messageText = messageText;
    self.authMessage.text = messageText;
}

@end
