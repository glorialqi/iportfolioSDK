//
//  Notes.m
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  Data model for storing a list of notes and the content of those notes.
//  Notes are optionally encrypted using AppConnect Secure File IO.
//

#import "Notes.h"
#import "Policies.h"
#import <AppConnect/NSData+ACSecureFile.h>
#import <AppConnect/NSFileManager+ACSecureFile.h>
#import <AppConnect/NSKeyedArchiver+ACSecureFile.h>
#import <AppConnect/NSKeyedUnarchiver+ACSecureFile.h>

@implementation Notes

static NSString * const noteListFilename = @"notelist";
static NSString * const noteFilenameBase = @"note";

+(NSError *)getNoteList:(NSArray **)pNoteList {
    NSError *error = nil;

    if ( !pNoteList ) {
        [NSException raise:@"Invalid argument to Notes method +getNoteList:" format:@"pNoteList must not be NULL"];
    }

    if (![[Policies sharedInstance] notesAvailable]) {
        *pNoteList = nil;
        return nil;
    }

    NSString *noteListFilepath = [Notes filepathForNoteList];
    NSFileManager *filemanager = [NSFileManager defaultManager];
    
    if ( ![filemanager fileExistsAtPath:noteListFilepath] ) {
        *pNoteList = [NSArray array];
        return nil;
    }

    NSArray *noteList = nil;
    @try {
        if ( [[Policies sharedInstance] useSecureFileIO] ) {
            noteList = [NSKeyedUnarchiver unarchiveObjectWithSecureFile:noteListFilepath error:&error];
        } else {
            noteList = [NSKeyedUnarchiver unarchiveObjectWithFile:noteListFilepath];
        }
        if ( !noteList ) {
            return error;
        }
    }
    @catch (NSException *e) {
        return nil;
    }
    
    *pNoteList = noteList;
    return nil;
}

+(NSError *)getContent:(NSString **)pNoteContent atIndex:(int)noteIndex {
    if ( !pNoteContent ) {
        [NSException raise:@"Invalid argument to Notes method +getContent:atIndex:" format:@"pNoteContent must not be NULL"];
    }
    
    if (![[Policies sharedInstance] notesAvailable]) {
        *pNoteContent = nil;
        return nil;
    }


    NSError *error;
    NSData *noteData;
    if ( [[Policies sharedInstance] useSecureFileIO] ) {
        noteData = [NSData dataWithContentsOfSecureFile:[Notes filepathForIndex:noteIndex] options:0 error:&error];
    } else {
        noteData = [NSData dataWithContentsOfFile:[Notes filepathForIndex:noteIndex] options:0 error:&error];
    }
    
    NSString *noteContent = [[NSString alloc] initWithData:noteData encoding:NSUTF8StringEncoding];
    if ( !noteContent ) {
        [NSException raise:@"Data error in Notes method +getContent:atIndex:" format:@"content does not contain a valid UTF8 string"];
    }
    
    *pNoteContent = noteContent;
    return error;
}

+(NSError *)addNote {
    if (![[Policies sharedInstance] notesAvailable]) {
        return [NSError errorWithDomain:@"com.mobileiron.enterprise.DualMode" code:0 userInfo:nil];
    }
    
    NSArray *noteList;
    NSError *error = [Notes getNoteList:&noteList];
    if ( error ) {
        return error;
    }
    
    int newIndex = (int)noteList.count;
    NSString *newFilepath = [Notes filepathForIndex:newIndex];
    if ( [[Policies sharedInstance] useSecureFileIO] ) {
        [[NSData data] writeToSecureFile:newFilepath options:0 error:&error];
    } else {
        [[NSData data] writeToFile:newFilepath options:0 error:&error];
    }
    if ( error ) {
        return error;
    }
    
    NSArray *newNoteList = [noteList arrayByAddingObject:@""];
    BOOL success;
    if ( [[Policies sharedInstance] useSecureFileIO] ) {
        success = [NSKeyedArchiver archiveRootObject:newNoteList toSecureFile:[Notes filepathForNoteList] error:&error];
    } else {
        success = [NSKeyedArchiver archiveRootObject:newNoteList toFile:[Notes filepathForNoteList]];
    }
    if ( !success ) {
        [[NSFileManager defaultManager] removeItemAtPath:newFilepath error:nil];
        return error;
    }

    return nil;
}

+(NSError *)setContent:(NSString *)content atIndex:(int)noteIndex {
    if ( !content ) {
        [NSException raise:@"Invalid argument to Notes method +setContent:atIndex:" format:@"content must not be nil"];
    }
    
    NSArray *noteList;
    BOOL success;
    NSError *error = [Notes getNoteList:&noteList];
    if ( error ) {
        return error;
    }
    
    if ( noteIndex < 0 || noteList.count < noteIndex ) {
        [NSException raise:@"Invalid argument to Notes method +setContent:atIndex:" format:@"noteIndex %i must be between 0 and %u inclusive", noteIndex, (int)(noteList.count-1)];
    }

    NSString *noteFilepath = [Notes filepathForIndex:noteIndex];
    NSData *noteData = [content dataUsingEncoding:NSUTF8StringEncoding];
    if ( [[Policies sharedInstance] useSecureFileIO] ) {
        success = [noteData writeToSecureFile:noteFilepath options:0 error:&error];
    } else {
        success = [noteData writeToFile:noteFilepath options:0 error:&error];
    }
    if ( !success ) {
        return error;
    }
    
    NSString *title = [Notes titleForContent:content];
    NSMutableArray *newNoteList = [NSMutableArray arrayWithArray:noteList];
    [newNoteList replaceObjectAtIndex:noteIndex withObject:title];
    if ( [[Policies sharedInstance] useSecureFileIO] ) {
        success = [NSKeyedArchiver archiveRootObject:newNoteList toSecureFile:[Notes filepathForNoteList] error:&error];
    } else {
        success = [NSKeyedArchiver archiveRootObject:newNoteList toFile:[Notes filepathForNoteList]];
    }
    if ( !success ) {
        return error;
    }
    
    return nil;
}

#pragma mark -
#pragma mark Private methods
+(NSString *)titleForContent:(NSString *)content {
    if ( !content ) {
        [NSException raise:@"Invalid argument to Notes method +titleForContent:" format:@"content must not be nil"];
    }
    
    NSRange titleRange;
    NSRange newlineRange = [content rangeOfString:@"\n"];
    titleRange.location = 0;
    titleRange.length = ( NSNotFound == newlineRange.location ) ? content.length : newlineRange.location;
    if ( 50 < titleRange.length ) {
        titleRange.length = 50;
    }
    
    return [content substringWithRange:titleRange];
}

+(NSString *)filepathForNoteList {
    return [[self applicationSupportDirectoryPath] stringByAppendingPathComponent:noteListFilename];
}

+(NSString *)filepathForIndex:(int)noteIndex {
    return [[self applicationSupportDirectoryPath] stringByAppendingPathComponent:[noteFilenameBase stringByAppendingFormat:@"%i", noteIndex]];
}

+(NSString *)applicationSupportDirectoryPath {
    NSString *applicationDocumentsDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *privateDocsDir = [applicationDocumentsDir stringByAppendingPathComponent:@"NotesData"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:privateDocsDir]) {
        NSError *error=nil;
        [[NSFileManager defaultManager] createDirectoryAtPath:privateDocsDir withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return privateDocsDir;
}

+(void)encryptAllData {
    if (![[Policies sharedInstance] notesAvailable]) {
        [NSException raise:@"Logic error in Notes method +encryptAllData" format:@"Secure services must be available"];
    }
    
    NSString *noteListFilepath = [Notes filepathForNoteList];
    NSFileManager *filemanager = [NSFileManager defaultManager];
    
    if ( ![filemanager fileExistsAtPath:noteListFilepath] ) {
        return;
    }
    
    NSArray *noteList = [NSKeyedUnarchiver unarchiveObjectWithFile:noteListFilepath];;
    if ( !noteList ) {
        // TBD:: Better error handling
        return;
    }
    
    NSError *error = nil;
    [filemanager removeItemAtPath:noteListFilepath error:&error];
    BOOL success = [NSKeyedArchiver archiveRootObject:noteList toSecureFile:noteListFilepath error:&error];
    
    for ( int i = 0; i < noteList.count; i++ ) {
        NSString *filepath = [Notes filepathForIndex:i];
        NSData *noteData = [NSData dataWithContentsOfFile:filepath options:0 error:&error];
        if (!error) {
            [filemanager removeItemAtPath:filepath error:&error];
            success = [noteData writeToSecureFile:filepath options:0 error:&error];
        }
    }
}

+(void)removeData {
    // Just delete the notes private docs directory
    [[NSFileManager defaultManager] removeItemAtPath:[Notes applicationSupportDirectoryPath] error:nil];
}

@end
