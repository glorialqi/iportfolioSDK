//
//  NotesViewController.m
//  DualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  View controller for showing the list of notes.
//

#import "NotesViewController.h"
#import "Notes.h"

@implementation NotesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Notes";
    self.splitViewController.delegate = self;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self refreshUI];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray *notes = nil;
    NSError *error = [Notes getNoteList:&notes];
    return (!error) ? [notes count] : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    NSArray *noteList = nil;
    NSError *error = [Notes getNoteList:&noteList];
    if (!error) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"NotesCell"];
        cell.textLabel.text = [noteList objectAtIndex:indexPath.row];
    }
    return cell;
}

// This will get called too before the view appears
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"ViewAndEditNote"]) {
        // Get destination view
        NotesDetailViewController *vc = (NotesDetailViewController *)[(UINavigationController *)[segue destinationViewController] topViewController];
        vc.delegate = self;
        NSIndexPath *noteIndexPath = [self.tableView indexPathForCell:sender];
        vc.noteIndex = noteIndexPath ? noteIndexPath.row : -1;
        // Hide master overlay when showing detail view
        if (self.splitViewController.displayMode == UISplitViewControllerDisplayModePrimaryOverlay) {
            UIBarButtonItem *displayButton = self.splitViewController.displayModeButtonItem;
            [[UIApplication sharedApplication] sendAction:displayButton.action to:displayButton.target from:nil forEvent:nil];
        }
    }
}

#pragma mark - NoteDetailDelegate methods
- (void)notesDetailViewController:(NotesDetailViewController *)notesDetailVC
             didUpdateNoteAtIndex:(NSInteger)noteIndex
                         withText:(NSString *)noteText {
    NSArray *notes = nil;
    NSError *error = [Notes getNoteList:&notes];
    if (!error && noteIndex >=0 && noteIndex < [notes count]) {
        [Notes setContent:noteText atIndex:(int)noteIndex];
    }
    else if (noteText.length > 0) {
        notesDetailVC.noteIndex = [self addNote:noteText];
    }
    [[self tableView] reloadData];
}

- (void)splitViewController:(UISplitViewController *)svc willChangeToDisplayMode:(UISplitViewControllerDisplayMode)displayMode {
    if (displayMode != UISplitViewControllerDisplayModePrimaryHidden) {
        [svc.view endEditing:YES];
    }
}

#pragma mark - public methods
// This is called in iPad. On iPhone, adding new note is handled through storyboard segue
- (IBAction)addNewNote {
    NSInteger newNoteIndex = [self addNote:@"New note"];
    if ( 0 <= newNoteIndex ) {
        NSIndexPath *newNoteIndexPath = [NSIndexPath indexPathForRow:newNoteIndex inSection:0];
        [self.tableView insertRowsAtIndexPaths:@[newNoteIndexPath] withRowAnimation:UITableViewRowAnimationNone];
        [self.tableView selectRowAtIndexPath:newNoteIndexPath animated:YES scrollPosition:UITableViewScrollPositionBottom];
        [self performSegueWithIdentifier:@"ViewAndEditNote" sender:[self.tableView cellForRowAtIndexPath:newNoteIndexPath]];
    }
}

- (void)refreshUI {
    [[self tableView] reloadData];
    [self.navigationItem setTitleView:[self customTitle]];
}

#pragma mark - private methods
// Returns the index of the note in the notes list
- (NSInteger)addNote:(NSString*)noteText {
    if ( [Notes addNote] ) {
        return -1;
    }
    NSArray *noteList=nil;
    NSInteger index = -1;
    NSError *error = [Notes getNoteList:&noteList];
    if (!error) {
        index = [noteList count]-1;
        [Notes setContent:noteText atIndex:(int)index];
    }
    return index;
}

// Custom UIView for title that adds MobileIron logo to the app title
- (UIView*)customTitle {
    float width = ([[Policies sharedInstance] state] == DMS_ACMode) ? 130 : 100;
    UIView *titleView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, width, 44)];
    
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 99, 44)];
    [lbl setText:@"Notes"];
    [lbl setNumberOfLines:1];
    [lbl setBackgroundColor:[UIColor clearColor]];
    [lbl setTextColor:[UIColor whiteColor]];
    [lbl setFont:[UIFont fontWithName:@"Helvetica-Bold" size:24]];
    [lbl setTextAlignment:NSTextAlignmentCenter];
    [lbl setShadowOffset:CGSizeMake(1, 1)];
    [titleView addSubview:lbl];
    
    if ([[Policies sharedInstance] state] == DMS_ACMode) {
        UIImageView *imageView =[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"mi-logo.png"]];
        imageView.frame=CGRectMake(99, 7, 30, 30);
        [titleView addSubview:imageView];
    }
    
    return titleView;
}

@end
