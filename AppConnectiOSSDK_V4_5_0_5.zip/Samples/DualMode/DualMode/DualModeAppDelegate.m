//
//  ACDualModeAppDelegate.m
//  ACSampleAppDualMode
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  UIApplicationDelegate for the app. Coordinates between model classes (Notes, Policies)
//  and various view classes.
//

#import "DualModeAppDelegate.h"
#import "NotesViewController.h"
#import "NotesDetailViewController.h"
#import "AuthMessageViewController.h"
#import "Policies.h"
#import "Notes.h"

@interface DualModeAppDelegate ()

@property (nonatomic) BOOL showingAppConnectAuthMessage;

@property (nonatomic, weak) NotesViewController *master;
@property (nonatomic, weak) NotesDetailViewController *detail;

@end

@implementation DualModeAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Customization
    if (!self.showingAppConnectAuthMessage) {
        [self setupSplitViewController:(UISplitViewController *)self.window.rootViewController];
    }
    
    [Policies initWithLaunchOptions:launchOptions];
    [self refreshUI];

    return YES;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [self refreshUI];
}

#pragma mark - public APIs
- (void)acModeChangeCompleted:(BOOL)success withReason:(NSString*)reason {
    [self refreshUI];
    NSString *alertTitle = @"MobileIron Management";
    NSString *alertMessage = success ?  @"This app is now managed by MobileIron." :
                                        [NSString stringWithFormat:@"Failed to enable MobileIron management of this app.\n\nReason: %@", reason];
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:alertTitle
                                                                             message:alertMessage
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    
    [self.window.rootViewController presentViewController:alertController animated:YES completion:nil];
}

- (void)nonAcModeChangeCompleted {
    [self refreshUI];
}

- (void)refreshUI {
    NSString *acAuthMessage = nil;
    BOOL displayAuthMessage = [[Policies sharedInstance] displayAuthMessage:&acAuthMessage];
    
    if (self.showingAppConnectAuthMessage) {
        if ( displayAuthMessage ) {
            // Ensure auth message is up to date
            UINavigationController *mainViewController = (UINavigationController*) self.window.rootViewController;
            AuthMessageViewController* authMessageViewController = (AuthMessageViewController*) mainViewController.topViewController;
            if ([authMessageViewController isMemberOfClass:[AuthMessageViewController class]]) {
                [authMessageViewController setMessageText:acAuthMessage];
            }
        } else {
            // Switch to root view
            [self switchToRootView];
        }
    } else {
        if ( displayAuthMessage ) {
            // Show the AppConnect auth message
            [self launchInAppConnectUnauthorizedState:acAuthMessage];
        } else {
            // Set up the delegate for master/detail controllers in spilt view controllers (iPad)
            [self setupSplitViewController:(UISplitViewController *)self.window.rootViewController];
            [self.master refreshUI];
            [self.detail reset];
        }
    }
}

- (void)setupSplitViewController:(UISplitViewController *)splitViewController {
    UINavigationController *masterNavigationController = [splitViewController.viewControllers firstObject];
    UINavigationController *detailNavigationController = [splitViewController.viewControllers lastObject];
    self.master = (NotesViewController *)masterNavigationController.topViewController;
    if (splitViewController.viewControllers.count == 1) {
        self.master = masterNavigationController.viewControllers.firstObject;
        if (masterNavigationController.viewControllers.count > 1) {
            detailNavigationController = (UINavigationController *)masterNavigationController.topViewController;
        }
        else {
            detailNavigationController = nil;
        }
    }

    self.detail = (NotesDetailViewController *)detailNavigationController.topViewController;
    self.detail.delegate = self.master;
    splitViewController.delegate = self.master;
    splitViewController.preferredDisplayMode = UISplitViewControllerDisplayModeAutomatic;
}

#pragma mark - private methods

- (void)launchInAppConnectUnauthorizedState:(NSString*)message {
    UIStoryboard *storyboard = [self.window.rootViewController storyboard];
    UINavigationController *mainViewController = [storyboard instantiateViewControllerWithIdentifier:@"UnauthorizedScreen"];
    AuthMessageViewController *topViewController = (AuthMessageViewController *)mainViewController.topViewController;
    topViewController.messageText = message;
    
    self.window.rootViewController = mainViewController;
    self.showingAppConnectAuthMessage = YES;
}

- (void)switchToRootView {
    if ([self showingAppConnectAuthMessage]) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UISplitViewController *splitViewController = [storyboard instantiateInitialViewController];
        
        // Set up the delegate for master/detail controllers in spilt view controllers (iPad)
        [self setupSplitViewController:splitViewController];
        self.window.rootViewController = splitViewController;
        self.showingAppConnectAuthMessage = NO;
    }
}

@end
