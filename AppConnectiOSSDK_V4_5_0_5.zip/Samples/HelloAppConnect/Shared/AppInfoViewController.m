//
//  AppInfoViewController.m
//  HelloAppConnect
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  YOUR USE AND DISTRIBUTION OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE DEVELOPMENT KIT (SDK) AGREEMENT BETWEEN
//  YOU AND MOBILE IRON, INC. (“MI”).  USE OR DISTRIBUTION NOT IN STRICT ACCORDANCE WITH THE AGREEMENT IS PROHIBITED.
//

#import "AppInfoViewController.h"
#import "AppConnectHandler.h"

@interface AppInfoViewController ()

@property (nonatomic, strong) IBOutlet UILabel *authSectionLabel;
@property (nonatomic, strong) IBOutlet UILabel *policySectionLabel;
@property (nonatomic, strong) IBOutlet UILabel *configSectionLabel;
@property (nonatomic, strong) IBOutlet UILabel *versionSectionLabel;

@property (nonatomic, strong) IBOutlet UITextView *authInfo;
@property (nonatomic, strong) IBOutlet UITextView *policyInfo;
@property (nonatomic, strong) IBOutlet UITextView *configInfo;
@property (nonatomic, strong) IBOutlet UILabel *versionInfoLabel;

@property (nonatomic, strong) IBOutlet UIScrollView *infoScrollView;

@property (nonatomic, strong) IBOutlet UIButton *stopRestartAppConnectButton;

@property (nonatomic) BOOL appConnectStopped;
@end

@implementation AppInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.appConnectStopped = NO;
    }
    return self;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [@[self.authInfo, self.policyInfo, self.configInfo] enumerateObjectsUsingBlock:^(UITextView * _Nonnull textView, NSUInteger idx, BOOL * _Nonnull stop) {
        [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
            [self updateHeightForTextView:textView boundingSize:size];
        } completion:nil];
        
    }];

    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

- (void)updateHeightForTextView:(UITextView *)textView boundingSize:(CGSize)size {
    for (NSLayoutConstraint *constraint in textView.constraints) {
        if (constraint.firstAttribute == NSLayoutAttributeHeight) {
            NSDictionary *attributes = nil == textView.font ? nil : @{ NSFontAttributeName : textView.font };
            
            CGFloat textHeight = [textView.text boundingRectWithSize:size
                                                             options:NSStringDrawingUsesLineFragmentOrigin
                                                          attributes:attributes
                                                             context:nil].size.height;
            constraint.constant = ceil(textHeight) + textView.textContainerInset.bottom + textView.textContainerInset.top;
            break;
        }
    }
}

- (void)updateTextView:(UITextView *)textView withText:(NSString *)newText {
    textView.text = newText;
    [self updateHeightForTextView:textView boundingSize:self.view.bounds.size];
}

- (void)updateAuthInfo:(NSString *)newInfo {
    [self updateTextView:self.authInfo withText:newInfo];
}

- (void)updateConfigInfo:(NSString *)newInfo {
    [self updateTextView:self.configInfo withText:newInfo];
}

- (void)updatePolicyInfo:(NSString *)newInfo {
    [self updateTextView:self.policyInfo withText:newInfo];
}

- (void)updateVersionInfo:(NSString *)newInfo {
    self.versionInfoLabel.text = newInfo;
}

-(IBAction) displayMessageButtonTouchUpInside:(id)sender {
    id<AppConnectHandler> appDelegate = (id<AppConnectHandler>)[[UIApplication sharedApplication] delegate];
    [appDelegate displayMessage];
}

-(IBAction)stopRestartAppConnect:(id)sender {
    id<AppConnectHandler> appDelegate = (id<AppConnectHandler>)[[UIApplication sharedApplication] delegate];
    NSString *alertTitle = NSLocalizedString(@"AppConnect", @"AppConnect");
    NSString *alertButtonTitle = NSLocalizedString(@"OK", @"close alert popup");
    NSString *alertMessage = nil;
    if (!self.appConnectStopped) {
        [appDelegate stopAppConnect];
        self.appConnectStopped = YES;
        [self.stopRestartAppConnectButton setTitle:@"Restart" forState:UIControlStateNormal];
        
        alertMessage = @"AppConnect has been stopped. You should not see any check-in from the app to MIClient or prompt for passcode.";
    }
    else {
        [appDelegate startAppConnectWithLaunchOptions:nil];
        self.appConnectStopped = NO;
        [self.stopRestartAppConnectButton setTitle:@"Retire & Stop" forState:UIControlStateNormal];
        
        alertMessage = @"AppConnect has been restarted. The app should check-in to MIClient after check-in interval and, if passcode is enabled, should prompt for passcode after inactivity duration.";
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:alertTitle
                                                                   message:alertMessage
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:alertButtonTitle style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:alertAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

@end
