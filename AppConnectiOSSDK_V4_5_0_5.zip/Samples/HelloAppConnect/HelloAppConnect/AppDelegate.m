//
//  AppDelegate.m
//  HelloAppConnect
//
//  Copyright (c) 2013-2017 MobileIron. All rights reserved.
//
//  YOUR USE AND DISTRIBUTION OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE DEVELOPMENT KIT (SDK) AGREEMENT BETWEEN
//  YOU AND MOBILE IRON, INC. (“MI”).  USE OR DISTRIBUTION NOT IN STRICT ACCORDANCE WITH THE AGREEMENT IS PROHIBITED.
//

#import "AppDelegate.h"


#import "AppInfoViewController.h"

@implementation AppDelegate

@synthesize appConnect = _appConnect;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [AppConnect logAtLevel:ACLogLevelStatus format:@"HelloAppConnect started"];

    self.viewController = (AppInfoViewController *)[(UINavigationController *)self.window.rootViewController topViewController];
    // Initialize the AppConnect library
    [self startAppConnectWithLaunchOptions:launchOptions];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [self updateLabels];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (BOOL)application:(UIApplication *)app openURL:(nonnull NSURL *)url options:(nonnull NSDictionary *)options {
    NSLog(@"%s called.", __FUNCTION__);
    return YES;
}

-(void) displayMessage {
    [self.appConnect displayMessage:self.appConnect.authMessage withCompletion:nil];
}

-(void) stopAppConnect {
    [[AppConnect sharedInstance] retire];
    [[AppConnect sharedInstance] stop];
    self.appConnect = nil;
    [self updateLabels];
}

-(void) startAppConnectWithLaunchOptions:(NSDictionary *)launchOptions {
    [AppConnect initWithDelegate:self];
    self.appConnect = [AppConnect sharedInstance];
    [self.appConnect startWithLaunchOptions:launchOptions];
}

-(void)appConnectIsReady:(AppConnect *)appConnect {
    [self updateLabels];
}

-(void) appConnect:(AppConnect *)appConnect managedPolicyChangedTo:(ACManagedPolicy)newManagedPolicy {
    [self updateLabels];
}

-(void) appConnect:(AppConnect *)appConnect authStateChangedTo:(ACAuthState)newAuthState withMessage:(NSString *)newMessage {
    NSString *authStateString;
    switch (newAuthState) {
        case ACAuthStateAuthorized:
            authStateString = @"authorized";
            break;
        case ACAuthStateRetired:
            authStateString = @"retired";
            break;
        case ACAuthStateUnauthorized:
            authStateString = @"unauthorized";
            break;
    }
    [AppConnect logAtLevel:ACLogLevelStatus format:@"authStateChangedTo: %@", authStateString];
    [self updateLabels];
    [appConnect authStateApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect pasteboardPolicyChangedTo:(ACPasteboardPolicy)newPasteboardPolicy {
    [self updateLabels];
    [appConnect pasteboardPolicyApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect openInPolicyChangedTo:(ACOpenInPolicy)newOpenInPolicy whitelist:(NSSet *)newWhitelist {
    [self updateLabels];
    [appConnect openInPolicyApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect printPolicyChangedTo:(ACPrintPolicy)newPrintPolicy {
    [self updateLabels];
    [appConnect printPolicyApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect secureFileIOPolicyChangedTo:(ACSecureFileIOPolicy)newSecureFileIOPolicy {
    [self updateLabels];
    [appConnect secureFileIOPolicyApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect secureServicesAvailabilityChangedTo:(ACSecureServicesAvailability)secureServicesAvailability {
    [self updateLabels];
}

-(void) appConnect:(AppConnect *)appConnect logLevelChangedTo:(ACLogLevel)logLevel {
    [self updateLabels];
}

-(void) appConnect:(AppConnect *)appConnect configChangedTo:(NSDictionary *)newConfig {
    [self updateLabels];
    [appConnect configApplied:ACPolicyStateApplied message:nil];
}

-(void) appConnect:(AppConnect *)appConnect copyAttemptedWhenUnauthorized:(ACPasteboardPolicy) securePasteBoardPolicy {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Secure Copy" message:@"You are not allowed to copy information in this app." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
}

-(void) updateLabels {
    [AppConnect logAtLevel:ACLogLevelVerbose format:@"Updating labels"];

    // Update authorization section
    NSString *authInfoText = nil;
    NSString *policyInfoText = nil;
    NSString *configInfoText = nil;
    if ([self.appConnect isReady]) {
        authInfoText = [self authInfoText];
        policyInfoText = [self policyInfoText];
        if (self.appConnect.config) {
            configInfoText = @"Configuration:\n{";
            for (NSString *key in self.appConnect.config) {
                configInfoText = [configInfoText stringByAppendingFormat:@"\n\t%@ = %@", key, [self.appConnect.config valueForKey:key]];
            }
            configInfoText = [configInfoText stringByAppendingString:@"\n}"];
        } else {
            configInfoText = @"Configuration:\n(none)";
        }
    } else {
        authInfoText = @"Ready: NO (AppConnect is not ready yet)";
        policyInfoText = @"AppConnect is not ready yet";
        configInfoText = @"AppConnect is not ready yet";
    }

    [self.viewController updateAuthInfo:authInfoText];
    [self.viewController updatePolicyInfo:policyInfoText];
    [self.viewController updateConfigInfo:configInfoText];
    
    // Update version section
    NSString *versionInfoText = [NSString stringWithFormat:@"AppConnect Version: %@", [AppConnect version]];
    [self.viewController updateVersionInfo:versionInfoText];
}

-(NSString*)authInfoText {
    NSString *authInfoText = [NSString stringWithFormat:@"Ready: %@", [self.appConnect isReady] ? @"YES": @"NO"];
    // Print
    
    switch ( self.appConnect.managedPolicy ) {
        case ACManagedPolicyUnmanaged:
            authInfoText = [authInfoText stringByAppendingString:@"\nManaged: Unmanaged"];
            break;
        case ACManagedPolicyManaged:
            authInfoText = [authInfoText stringByAppendingString:@"\nManaged: Managed"];
            break;
        case ACManagedPolicyUnknown:
        default:
            authInfoText = [authInfoText stringByAppendingString:@"\nManaged: Unknown"];
            break;
    }
    
    switch ( self.appConnect.authState ) {
        case ACAuthStateUnauthorized:
            authInfoText = [authInfoText stringByAppendingString:@"\nAuth State: Unauthorized"];
            break;
        case ACAuthStateAuthorized:
            authInfoText = [authInfoText stringByAppendingString:@"\nAuth State: Authorized"];
            break;
        case ACAuthStateRetired:
            authInfoText = [authInfoText stringByAppendingString:@"\nAuth State: Retired"];
            break;
        default:
            authInfoText = [authInfoText stringByAppendingString:@"\nAuth State: Unknown"];
            break;
    }
    authInfoText = [NSString stringWithFormat:@"%@\nAuth Message: %@", authInfoText, self.appConnect.authMessage];
    
    // Secure services availability
    switch ( self.appConnect.secureServicesAvailability ) {
        case ACSecureServicesAvailabilityAvailable:
            authInfoText = [authInfoText stringByAppendingString:@"\nSecure Services: Available"];
            break;
        case ACSecureServicesAvailabilityUnavailable:
            authInfoText = [authInfoText stringByAppendingString:@"\nSecure Services: Unavailable"];
            break;
        default:
            authInfoText = [authInfoText stringByAppendingString:@"\nSecure Services: Unknown"];
            break;
    }
    
    return authInfoText;
}

-(NSString*)policyInfoText {
    // Update policy section
    NSMutableString *policyInfoText = [NSMutableString string];
    
    // Pasteboard
    switch ( self.appConnect.pasteboardPolicy ) {
        case ACPasteboardPolicyUnauthorized:
            [policyInfoText appendString:@"Pasteboard: Unauthorized\n"];
            break;
        case ACPasteboardPolicyAuthorized:
            [policyInfoText appendString:@"Pasteboard: Authorized\n"];
            break;
        case ACPasteboardPolicySecureCopy:
            [policyInfoText appendString:@"Pasteboard: Secure Copy (AppConnect Apps)\n"];
            break;
        default:
            [policyInfoText appendString:@"Pasteboard: Policy Unknown\n"];
            break;
    }
    
    // OpenIn
    switch ( self.appConnect.openInPolicy ) {
        case ACOpenInPolicyUnauthorized:
            [policyInfoText appendString:@"Open In: Unauthorized\n"];
            break;
        case ACOpenInPolicyAuthorized:
            [policyInfoText appendString:@"Open In: Authorized for all apps\n"];
            break;
        case ACOpenInPolicyWhitelist: {
            NSString *whitelistEntries;
            if ( 0 == self.appConnect.openInWhitelist.count ) {
                whitelistEntries = @"(none)\n";
            } else {
                whitelistEntries = @"\n";
                for ( NSString *entry in self.appConnect.openInWhitelist ) {
                    whitelistEntries = [whitelistEntries stringByAppendingFormat:@"   %@\n", entry];
                }
            }
            [policyInfoText appendString:[NSString stringWithFormat:@"Open In: Authorized for whitelist: %@", whitelistEntries]];
            break;
        }
        default:
            [policyInfoText appendString:@"Open In: Policy Unknown\n"];
            break;
    }
    
    // Print
    switch ( self.appConnect.printPolicy ) {
        case ACPrintPolicyAuthorized:
            [policyInfoText appendString:@"Print: Authorized\n"];
            break;
        case ACPrintPolicyUnauthorized:
            [policyInfoText appendString:@"Print: Unauthorized\n"];
            break;
        default:
            [policyInfoText appendString:@"Print: Policy Unknown\n"];
            break;
    }
    
    // Secure File IO
    switch ( self.appConnect.secureFileIOPolicy ) {
        case ACSecureFileIOPolicyOptional:
            [policyInfoText appendString:@"Secure File IO: Optional\n"];
            break;
        case ACSecureFileIOPolicyRequired:
            [policyInfoText appendString:@"Secure File IO: Required\n"];
            break;
        default:
            [policyInfoText appendString:@"Secure File IO: Policy Unknown\n"];
            break;
    }
    
    // Log level
    switch ( [AppConnect logLevel] ) {
        case ACLogLevelStatus:
            [policyInfoText appendString:@"Log Level: Status"];
            break;
        case ACLogLevelWarning:
            [policyInfoText appendString:@"Log Level: Warning"];
            break;
        case ACLogLevelError:
            [policyInfoText appendString:@"Log Level: Error"];
            break;
        case ACLogLevelInfo:
            [policyInfoText appendString:@"Log Level: Info"];
            break;
        case ACLogLevelVerbose:
            [policyInfoText appendString:@"Log Level: Verbose"];
            break;
        case ACLogLevelDebug:
            [policyInfoText appendString:@"Log Level: Debug"];
            break;
        default:
            [policyInfoText appendString:@"Log Level: Unknown"];
            break;
    }
    
    return policyInfoText;
}

@end
