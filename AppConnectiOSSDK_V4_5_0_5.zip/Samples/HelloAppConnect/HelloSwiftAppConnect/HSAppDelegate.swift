//
//  HSAppDelegate.swift
//  HelloSwiftAppConnect
//
//  Copyright (c) 2017 MobileIron. All rights reserved.
//
//  YOUR USE AND DISTRIBUTION OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE DEVELOPMENT KIT (SDK) AGREEMENT BETWEEN
//  YOU AND MOBILE IRON, INC. (“MI”).  USE OR DISTRIBUTION NOT IN STRICT ACCORDANCE WITH THE AGREEMENT IS PROHIBITED.
//

import UIKit
import AppConnect

class HSAppDelegate: UIResponder, UIApplicationDelegate, AppConnectHandler {
    
    var window: UIWindow?
    var viewController: AppInfoViewController? {
        return (self.window?.rootViewController as? UINavigationController)?.topViewController as? AppInfoViewController
    }
    var appConnect: AppConnect?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        AppConnect.log(at: .status, message: "HelloAppConnect started")
        self.startAppConnect(launchOptions: launchOptions)
        return true
    }
    
    func applicationDidBecomeActiveFromAppConnect(_ appConnect: AppConnect) {
        self.updateLabels()
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        AppConnect.log(at: .debug, message: "\(#function) called.")
        return true
    }
    
    func displayMessage() {
        self.appConnect?.displayMessage(self.appConnect?.authMessage, withCompletion: nil)
    }

    func stopAppConnect() {
        self.appConnect!.retire()
        self.appConnect!.stop()
        self.appConnect = nil
        self.updateLabels()
    }

    func startAppConnect(launchOptions: [AnyHashable : Any]? = [:]) {
        AppConnect.initWith(self)
        self.appConnect = AppConnect.sharedInstance()
        self.appConnect!.start(launchOptions: launchOptions)
    }
    
    func appConnectIsReady(_ appConnect: AppConnect) {
        self.updateLabels()
    }
    
    func appConnect(_ appConnect: AppConnect, managedPolicyChangedTo newManagedPolicy: ACManagedPolicy) {
        self.updateLabels()
    }
    
    func appConnect(_ appConnect: AppConnect, authStateChangedTo newAuthState: ACAuthState, withMessage message: String?) {
        AppConnect.log(at: .status, message: "authStateChangedTo: \(newAuthState)")
        self.updateLabels()
        appConnect.authStateApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, pasteboardPolicyChangedTo newPasteboardPolicy: ACPasteboardPolicy) {
        self.updateLabels()
        appConnect.pasteboardPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, openInPolicyChangedTo newOpenInPolicy: ACOpenInPolicy, whitelist newWhitelist: Set<String>) {
        self.updateLabels()
        appConnect.openInPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, printPolicyChangedTo newPrintPolicy: ACPrintPolicy) {
        self.updateLabels()
        appConnect.printPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, secureFileIOPolicyChangedTo newSecureFileIOPolicy: ACSecureFileIOPolicy) {
        self.updateLabels()
        appConnect.secureFileIOPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, secureServicesAvailabilityChangedTo secureServicesAvailability: ACSecureServicesAvailability) {
        self.updateLabels()
    }
    
    func appConnect(_ appConnect: AppConnect, logLevelChangedTo newLogLevel: ACLogLevel) {
        self.updateLabels()
    }
    
    func appConnect(_ appConnect: AppConnect, configChangedTo newConfig: [AnyHashable : Any]) {
        self.updateLabels()
        appConnect.configApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, copyAttemptedWhenUnauthorized pasteboardPolicy: ACPasteboardPolicy) {
        let alert = UIAlertController(title: "Secure Copy", message: "You are not allowed to copy information in this app.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(okAction)
        
        self.viewController?.present(alert, animated: true, completion: nil)
    }

    func updateLabels() {
        AppConnect.log(at: .verbose, message: "Updating labels")
        self.viewController?.updateAuthInfo(self.authInfoText())
        self.viewController?.updatePolicyInfo(self.policyInfoText())
        self.viewController?.updateConfigInfo(self.configInfoText())
        self.viewController?.updateVersionInfo("AppConnect Version: \(AppConnect.version())")
    }
    
    func authInfoText() -> String {
        guard let appConnect = self.appConnect, appConnect.isReady else {
            return "Ready: NO (AppConnect is not ready yet)"
        }
        var result = "Ready: \(appConnect.isReady == true ? "YES" : "NO")\n"
        result.append("Managed: \(appConnect.managedPolicy.description)\n")
        result.append("Atuh state: \(appConnect.authState.description)\n")
        result.append("Auth message: \(appConnect.authMessage ?? "(none)")\n")
        result.append("Secure services: \(appConnect.secureServicesAvailability)")
        return result
    }
    
    func policyInfoText() -> String {
        guard let appConnect = self.appConnect, appConnect.isReady else {
            return "AppConnect is not ready yet"
        }
        var whiteListEntries = ""
        if (appConnect.openInPolicy == .whitelist) {
            whiteListEntries = appConnect.openInWhitelist.count == 0 ? ": (none)" : ":\n"
            for entry in appConnect.openInWhitelist {
                whiteListEntries.append("\(entry as! String)\n")
            }
        }
        var result = "Pasteboard Policy: \(appConnect.pasteboardPolicy)\n"
        result.append("Open In Policy: \(appConnect.openInPolicy)\(whiteListEntries)\n")
        result.append("Print Policy: \(appConnect.printPolicy)\n")
        result.append("Secure File IO Policy: \(appConnect.secureFileIOPolicy)\n")
        result.append("Log Level: \(AppConnect.logLevel())")
        return result
    }
    
    func configInfoText() -> String {
        guard let appConnect = self.appConnect, appConnect.isReady else {
            return "AppConnect is not ready yet"
        }
        var result = "Configuration:\n{"
        for entry in appConnect.config.enumerated() {
            result.append("\n\t\(entry.element.key as! String) = \(entry.element.value as! String)")
        }
        result.append("\n}")
        
        return result
    }
}
