//
//  AppConnectService.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import Foundation
import AppConnect

let kAppConnectStateUserDefaultsKey = "AppConnectState"

enum AppConnectState: Int {
    // Skip 0 to properly handle value missing in UserDefaults
    case Undefined = 1
    case Unmanaged
    case Unauthorized
    case Retired
    case Authorized
    
    func isManagedMode() -> Bool {
        return (self != .Undefined) && (self != .Unmanaged)
    }
}

enum StateChangeReason: Int {
    case Authorization
    case Security
}

class AppConnectService: NSObject, AppConnectDelegate {
    private var stateHandler: ((StateChangeReason) -> Void)?
    private var appConnect: AppConnect! {
        didSet {
            if (nil == appConnect) {
                self.appConnectState = .Unmanaged
            }
            else {
                self.updateState()
            }
        }
    }
    
    private(set) var appConnectState = AppConnectState(rawValue: UserDefaults.standard.integer(forKey: kAppConnectStateUserDefaultsKey)) ?? .Undefined  {
        didSet {
            if (oldValue != appConnectState) {
                if (.Retired == appConnectState && !oldValue.isManagedMode()) {
                    appConnectState = .Unauthorized
                }
                if (.Undefined != appConnectState) {
                    self.stateHandler?(.Authorization)
                }                
            }
            if (.Undefined != appConnectState) {
                UserDefaults.standard.set(appConnectState.rawValue, forKey: kAppConnectStateUserDefaultsKey)
                UserDefaults.standard.synchronize()
            }
        }
    }
    private(set) var appConnectAuthMessage: String?

    var secureFilesRequired: Bool {
        return self.secureFilesAvailable && (self.appConnect.secureFileIOPolicy == .required)
    }
    
    var secureFilesAvailable: Bool {
        return (true == self.appConnect?.isReady) && (self.appConnect.secureServicesAvailability == .available)
    }
    
    func startAppConnect(with launchOptions: [UIApplication.LaunchOptionsKey : Any]?, _ handler: @escaping (StateChangeReason) -> Void) {
        if (nil != self.appConnect) {
            AppConnect.log(at: .error, message: "AppConnect is already started")
            return
        }
        self.stateHandler = handler
        if (AppConnect.shouldStart()) {
            AppConnect.initWith(self)
            self.appConnect = AppConnect.sharedInstance()
            self.appConnect.start(launchOptions: launchOptions)
        }
        else {
            self.appConnectState = .Unauthorized
        }
    }
    
    func stop() {
        self.appConnect?.retire()
        self.appConnect?.stop()
        self.appConnect = nil
    }
    
    private func updateState() {
        if (true != self.appConnect?.isReady) {
            self.appConnectState = .Undefined
            return
        }
        switch self.appConnect.authState {
        case .retired:
            self.appConnectState = .Retired
        case .authorized:
            self.appConnectState = .Authorized
        case .unauthorized:
            self.appConnectState = .Unauthorized
        default:
            AppConnect.log(at: .error, message: "Unknown AppConnect auth state")
        }
    }
    
    private func reportError(_ message: String, title: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        if let window = UIApplication.shared.delegate?.window {
            window?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
    
    func appConnectIsReady(_ appConnect: AppConnect) {
        AppConnect.log(at: .status, message: "AppConnect Ready")
        appConnect.enableAppExtensionSupport()
        self.updateState()
    }
    
    func appConnect(_ appConnect: AppConnect, authStateChangedTo newAuthState: ACAuthState, withMessage message: String?) {
        AppConnect.log(at: .status, message: "AppConnect auth state changed to \(newAuthState): (\(String(describing: message)))")
        self.appConnectAuthMessage = message
        self.updateState()
        appConnect.authStateApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, managedPolicyChangedTo newManagedPolicy: ACManagedPolicy) {
        AppConnect.log(at: .status, message: "AppConnect managed policy changed to \(newManagedPolicy)")
        if (.Unmanaged == self.appConnectState) {
            if (.managed == newManagedPolicy) {
                self.updateState()
            }
        }
        else if (.Undefined != self.appConnectState && .unmanaged == newManagedPolicy) {
            self.stop()
        }
    }

    func appConnect(_ appConnect: AppConnect, openInPolicyChangedTo newOpenInPolicy: ACOpenInPolicy, whitelist newWhitelist: Set<String>) {
        AppConnect.log(at: .status, message: "AppConnect openIn policy changed to \(newOpenInPolicy).\nWhiteList: \(newWhitelist)")
        self.appConnect.openInPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, printPolicyChangedTo newPrintPolicy: ACPrintPolicy) {
        AppConnect.log(at: .status, message: "AppConnect Print policy changed to \(newPrintPolicy)")
        self.appConnect.printPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, pasteboardPolicyChangedTo newPasteboardPolicy: ACPasteboardPolicy) {
        AppConnect.log(at: .status, message: "AppConnect Pasteboard policy changed to \(newPasteboardPolicy)")
        self.appConnect.pasteboardPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, secureFileIOPolicyChangedTo newSecureFileIOPolicy: ACSecureFileIOPolicy) {
        AppConnect.log(at: .status, message: "AppConnect secureFileIO policy changed to \(newSecureFileIOPolicy)")
        self.stateHandler?(.Security)
        self.appConnect.secureFileIOPolicyApplied(.applied, message: nil)
    }
    
    func appConnect(_ appConnect: AppConnect, configChangedTo newConfig: [AnyHashable : Any]) {
        AppConnect.log(at: .status, message: "AppConnect config changed to \(newConfig)")
        self.appConnect.configApplied(.applied, message: nil)
    }

    func appConnect(_ appConnect: AppConnect, secureServicesAvailabilityChangedTo secureServicesAvailability: ACSecureServicesAvailability) {
        AppConnect.log(at: .status, message: "AppConnect secure service availablility changed to \(secureServicesAvailability)")
        setupWrappedKeys(secureServicesAvailability)
        self.stateHandler?(.Security)
    }
    
    func appConnect(_ appConnect: AppConnect, openInAttemptedWhenACOpenInPolicyBlocked openInPolicy: ACOpenInPolicy) {
        self.reportError("You are not allowed to share information with this app.", title: "Secure Copy")
    }
    
    func appConnect(_ appConnect: AppConnect, copyAttemptedWhenUnauthorized pasteboardPolicy: ACPasteboardPolicy) {
        self.reportError("Unable to copy data", title: "Operation is not allowed")
    }

    fileprivate func setupWrappedKeys(_ secureServicesAvailability: ACSecureServicesAvailability) {
        let sharedDefaults = UserDefaults.init(suiteName: FileProviderConstants.appGroupIdentifier)
        if secureServicesAvailability == .available {
            do {
                let secureKeyData: Data? = try ACWrappedAppKey.getCryptoKeysForACFileEncryption(withSharedGroupID: nil)
                guard secureKeyData != nil else {
                    AppConnect.log(at: .error, message: "Unable to retrieve wrapped keys")
                    return
                }
                sharedDefaults?.set(secureKeyData, forKey: FileProviderConstants.wrappedCryptoDefaultKey)
                sharedDefaults?.synchronize()
            }
            catch {
                AppConnect.log(at: .status, message: "Exception thrown when saving wrapped keys.")
            }
        } else {
            sharedDefaults?.removeObject(forKey: FileProviderConstants.wrappedCryptoDefaultKey)
        }
    }
}
