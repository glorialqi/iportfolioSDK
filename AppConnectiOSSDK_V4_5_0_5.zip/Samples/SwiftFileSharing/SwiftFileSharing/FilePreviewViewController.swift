//
//  FilePreviewViewController.swift
//  SwiftFileSharing
//
//  Created by Paul Budzinsky on 7/20/17.
//  Copyright © 2017 Mobileiron. All rights reserved.
//

import UIKit

class FilePreviewViewController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!
    var fileURL: URL?
    
    var documentInteractionController: UIDocumentInteractionController?
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if (nil != self.fileURL) {
            self.navigationItem.title = self.fileURL!.lastPathComponent
            self.webView.loadRequest(URLRequest(url: self.fileURL!))
        }
    }
    
    @IBAction func shareAction(sender: UIBarButtonItem?) {
        if (nil == self.fileURL) {
            return
        }
        self.documentInteractionController = UIDocumentInteractionController(url: self.fileURL!)
        if (nil == self.documentInteractionController ||
            !self.documentInteractionController!.presentOpenInMenu(from: sender!, animated: true)) {
            let alertController = UIAlertController.init(title: "Can't open file",
                message: "Unexpected error. Can't open \(self.fileURL!.lastPathComponent)",
                preferredStyle: .alert)
            alertController.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
}
