//
//  FileListViewController.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import UIKit

class FileListViewController: UITableViewController {
    
    private var fileListObserver: NSObjectProtocol?
    private var fileProvider: FileProvider!
    private var selectedFileURL: URL?
    
    private lazy var footerLabel: UILabel = {
        let result = UILabel()
        result.numberOfLines = 0
        return result
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let notificationName = NSNotification.Name(rawValue: FileProviderConstants.didRefreshFileListNotificationName)
        self.fileListObserver = NotificationCenter.default.addObserver(forName: notificationName, object: nil, queue: OperationQueue.main) { [weak self] (_) in
            self?.tableView.reloadData()
        }
        
        self.fileProvider = (UIApplication.shared.delegate as! AppDelegate).fileProvider
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
        super.viewWillAppear(animated)
    }
    
    deinit {
        if (nil != self.fileListObserver) {
            NotificationCenter.default.removeObserver(self.fileListObserver!)
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.fileProvider.locked ? 0 : self.fileProvider.numberOfFiles
    }
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return self.fileProvider.locked ? self.footerLabel : nil
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if (self.fileProvider.locked) {
            self.footerLabel.text = self.fileProvider.lockReason ?? "Application is not authorized.\nFiles are not accessible.\nMake sure that M@W is installed on the device and try again"
            self.footerLabel.frame.size = self.footerLabel.sizeThatFits(self.tableView.frame.size)
            
            return self.footerLabel.frame.height
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileListCell", for: indexPath)
        cell.textLabel?.text = self.fileProvider.fileName(at: indexPath.row)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if .delete == editingStyle {
            do {
                try self.fileProvider.removeFile(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }
            catch let error as NSError {
                let alertController = UIAlertController(title: "Failed to remove file", message: error.localizedDescription, preferredStyle: .alert)
                alertController.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if ("OpenFileSegue" == identifier) {
            guard let cell = sender as? UITableViewCell, let selectedIndexPath = self.tableView.indexPath(for: cell) else {
                return false
            }

            self.selectedFileURL = self.fileProvider.preparedFileURL(at: selectedIndexPath.row)
            return nil != self.selectedFileURL
        }
        
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? FilePreviewViewController, let fileURL = self.selectedFileURL {
            destinationVC.fileURL = fileURL
            self.selectedFileURL = nil
        }
    }
}
