//
//  SecureStorage.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import Foundation
import AppConnect

class SecureStorage: RegularStorage {
    override class var contentFolderName: String {
        return ".SecureFiles"
    }
    
    override func createFile(withName fileName: String, data fileData: Data) throws {
        let destinationURL = self.storageFileURL(with: fileName)
        try FileManager.default.createSecureFile(atPath: destinationURL.path, contents: fileData, attributes: nil)
    }
    
    override func enumerateFiles(_ block: (String, Data) -> Void) {
        self.enumerateFileURLs { (fileURL) in
            if let fileContent = NSData.init(contentsOfSecureFile: fileURL.path) {
                block(fileURL.lastPathComponent, fileContent as Data)
            }
        }
    }
    
    override func consumeFile(at sourceFileURL: URL) throws {
        if let fileContent = try? Data.init(contentsOf: sourceFileURL) {
            try self.createFile(withName: sourceFileURL.lastPathComponent, data: fileContent)
            try FileManager.default.removeItem(at: sourceFileURL)
        }
    }
    
    override func presentationURL(withName fileName: String) -> URL? {
        if let fileContent = NSData.init(contentsOfSecureURL: self.contentFolderURL.appendingPathComponent(fileName)) {
            let temporaryFileURL = URL(fileURLWithPath: NSTemporaryDirectory(), relativeTo: nil).appendingPathComponent(fileName)
            try? FileManager.default.removeItem(at: temporaryFileURL)
            fileContent.write(to: temporaryFileURL, atomically: true)
            return temporaryFileURL
        }
        return nil
    }
}

