//
//  RegularStorage.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import Foundation

protocol StorageService {
    func fileNames() -> [String]
    func enumerateFiles(_ block: (String, Data) -> Void)
    func presentationURL(withName fileName: String) -> URL?
    
    func createFile(withName fileName: String, data fileData: Data) throws
    func consumeFile(at sourceFileURL: URL) throws
    
    func deleteFile(withName fileName: String) throws
    func deleteAll() throws
}


class RegularStorage: StorageService {
    
    class var contentFolderName: String {
        return ".Files"
    }
    
    internal var contentFolderURL: URL
    internal func storageFileURL(with name: String) -> URL {
        var result = self.contentFolderURL.appendingPathComponent(name)
        let pathExtension = result.pathExtension
        let name = result.deletingPathExtension().lastPathComponent
        for index in 2...Int.max {
            if !FileManager.default.fileExists(atPath: result.path) {
                break;
            }
            result = self.contentFolderURL.appendingPathComponent("\(name)-\(index)\(pathExtension.isEmpty ? pathExtension : ".".appending(pathExtension))")
        }
        
        return result
    }
    
    private func setupFolder() throws {
        try FileManager.default.createDirectory(at: self.contentFolderURL, withIntermediateDirectories: true, attributes: nil)
    }
    
    required init?(withRoot rootURL: URL) {
        self.contentFolderURL = rootURL.appendingPathComponent(type(of: self).contentFolderName)
        
        do {
            try self.setupFolder()
        }
        catch {
            return nil
        }
    }
    
    
    internal func enumerateFileURLs(_ block: (URL) -> Void) {
        let allFiles = (try? FileManager.default.contentsOfDirectory(at: self.contentFolderURL,
                                                                     includingPropertiesForKeys: nil,
                                                                     options: .skipsSubdirectoryDescendants))
        
        allFiles?.forEach { block($0) }
    }
    
    func fileNames() -> [String] {
        var result: [String] = []
        self.enumerateFileURLs { result.append($0.lastPathComponent) }
        return result
    }
    
    func enumerateFiles(_ block: (String, Data) -> Void) {
        self.enumerateFileURLs {
            if let fileContent = try? Data(contentsOf: $0) {
                block($0.lastPathComponent, fileContent)
            }
        }
    }
    
    func presentationURL(withName fileName: String) -> URL? {
        return self.contentFolderURL.appendingPathComponent(fileName)
    }
    
    func createFile(withName fileName: String, data fileData: Data) throws {
        try fileData.write(to: self.storageFileURL(with: fileName))
    }
    
    func consumeFile(at sourceFileURL: URL) throws {
        try FileManager.default.moveItem(at: sourceFileURL, to: self.storageFileURL(with: sourceFileURL.lastPathComponent))
    }
    
    func deleteFile(withName fileName: String) throws {
        try FileManager.default.removeItem(at: self.contentFolderURL.appendingPathComponent(fileName))
    }
    
    func deleteAll() throws {
        try FileManager.default.removeItem(at: self.contentFolderURL)
        try self.setupFolder()
    }
}
