//
//  PreferencesViewController.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import UIKit

class PreferencesViewController: UIViewController {

    @IBOutlet var managedModeSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "Preferences"
        UserDefaults.standard.addObserver(self, forKeyPath: kAppConnectStateUserDefaultsKey, options: [.new, .initial], context: nil)
    }
    
    deinit {
        UserDefaults.standard.removeObserver(self, forKeyPath: kAppConnectStateUserDefaultsKey)
    }
    
    @IBAction func toggleMangedMode(_ sender: Any?) {
        let newState = (sender as? UISwitch)?.isOn ?? false
        var okActionStyle = UIAlertAction.Style.default
        var alertMessage = "This app will attempt to be secured and managed by MobileIron.\nTap Cancel to keep this app unsecured and unmanaged."

        if (!newState) {
            alertMessage = "This app will no longer be managed by MobileIron. All your files will be permanently erased.\nTap Cancel to keep your files and keep this app managed by MobileIron."
            okActionStyle = .destructive
        }
        
        let okAction = UIAlertAction.init(title: "OK", style: okActionStyle, handler: { (_) in
            (UIApplication.shared.delegate as? AppDelegate)?.attemptSwitch(to: newState)
        })
        let cancelAction = UIAlertAction.init(title: "Cancel", style: .cancel) { (_) in
            self.managedModeSwitch.isOn = !newState
        }

        let stateAlert = UIAlertController.init(title: "MobileIron Management", message: alertMessage, preferredStyle: .alert)
        stateAlert.addAction(okAction)
        stateAlert.addAction(cancelAction)
        self.present(stateAlert, animated: true, completion: nil)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if (UserDefaults.standard == (object as? NSObject) && kAppConnectStateUserDefaultsKey == keyPath) {
            guard let newStateValue = (change?[NSKeyValueChangeKey.newKey] as? Int) else {
                return
            }
            self.managedModeSwitch.isOn = AppConnectState(rawValue: newStateValue)?.isManagedMode() ?? false
        }
        else {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
        }
    }
}
