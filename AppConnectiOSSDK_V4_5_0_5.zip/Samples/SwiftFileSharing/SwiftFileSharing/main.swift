//
//  main.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import Foundation
import AppConnect

UIApplicationMain(
    CommandLine.argc,
    CommandLine.unsafeArgv,
    ACUIApplicationClassName,
    NSStringFromClass(AppDelegate.self)
)
