//
//  FileProviderConstants.swift
//  SwiftFileSharing
//
//  Created on 5/22/18.
//  Copyright © 2018 Mobileiron. All rights reserved.
//
import UIKit

struct FileProviderConstants {
    static let didRefreshFileListNotificationName = "FileProviderDidRefreshFileList"

    static let errorDomain = "\(Bundle.main.bundleIdentifier!).fileProviderError"

    static let secureModeUserDefaultsKey = "SecureMode"

    /*
     NOTE: appGroupIdentifier comes from entitlements.
     When you build this app, using your provisioning profiles and developer identities, you will need to create your own app group.
     For creating your app group go to Project Settings -> Capabilities -> App Groups and update the group name there.
     After that update this constant to match.
     NOTE: THIS VALUE SHOULD MATCH ENTITLEMENTS ENTRY FOR App Groups. A BETTER PRACTICE IS TO MATCH IT WITH YOUR BUNDLE IDENTIFIER.
     */
    static let appGroupIdentifier = "group.com.mobileiron.enterprise.SwiftFileSharing2"

    static let wrappedCryptoDefaultKey = "wrappedCryptoDefaultKey"
}
