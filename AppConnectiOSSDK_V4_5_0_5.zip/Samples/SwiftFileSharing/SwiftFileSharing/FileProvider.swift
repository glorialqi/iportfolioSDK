//
//  FileProvider.swift
//  SwiftFileSharing
//
//  Copyright (c) 2017 Mobileiron. All rights reserved.
//

import Foundation

class FileProvider {
    
    private var fileList = [String]()
    private var fileStorage: StorageService!
    private var folderMonitor: DispatchSourceFileSystemObject!

    class var documentsFolder: URL {
        let containerURL = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: FileProviderConstants.appGroupIdentifier)
        guard containerURL != nil else {return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!}
        return containerURL!
    }
    
    private func migrate(fromStorage oldStorage: StorageService?) {
        let rootURL = type(of: self).documentsFolder
        self.fileStorage = self.secureMode! ? SecureStorage.init(withRoot: rootURL) : RegularStorage.init(withRoot: rootURL)
        
        oldStorage?.enumerateFiles({ (fileName, fileContent) in
            try? self.fileStorage.createFile(withName: fileName, data: fileContent)
        })
        try? oldStorage?.deleteAll()
    }
    
    init?() {
        self.migrate(fromStorage: nil)
        self.processDocumentsFolder()
        do {
            try self.startMonitoring(at: type(of: self).documentsFolder)
        }
        catch {
            return nil
        }
    }
    
    private func refreshFileList() {
        self.fileList = self.fileStorage.fileNames().sorted()
        let notificationName = NSNotification.Name(rawValue: FileProviderConstants.didRefreshFileListNotificationName)
        NotificationCenter.default.post(name: notificationName, object: self)
    }
    
    private func processDocumentsFolder() {
        let allFiles = (try? FileManager.default.contentsOfDirectory(at: type(of: self).documentsFolder,
                                                                     includingPropertiesForKeys: nil,
                                                                     options: .skipsSubdirectoryDescendants)) ?? []
        for fileURL in allFiles {
            var isDirectoryFlag: ObjCBool = ObjCBool.init(false)
            FileManager.default.fileExists(atPath: fileURL.path, isDirectory: &isDirectoryFlag)
            if (!isDirectoryFlag.boolValue) {
                try? self.fileStorage.consumeFile(at: fileURL)
            }
        }
        
        self.refreshFileList()
    }
    
    private func startMonitoring(at folderURL: URL) throws {
        if (nil == folderMonitor) {
            let folderDescriptor = open((type(of: self).documentsFolder.path as NSString).fileSystemRepresentation, O_EVTONLY);
            if (0 >= folderDescriptor) {
                throw NSError.init(domain: FileProviderConstants.errorDomain, code: -1,
                                   userInfo: [ NSLocalizedDescriptionKey : "Failed to open folder: \(folderURL)"])
            }
            folderMonitor = DispatchSource.makeFileSystemObjectSource(fileDescriptor: folderDescriptor, eventMask: [.write]);
            folderMonitor.setEventHandler { [weak self] in
                // Throttle FS events handling to allow underlying FileManager to get actual FS state after previous update
                usleep(100 * 1000)
                self?.processDocumentsFolder()
            }
            folderMonitor.setCancelHandler { [weak self] in
                if (nil != self) {
                    close(self!.folderMonitor.handle)
                    self!.folderMonitor = nil
                }
            }
        }
        self.folderMonitor.resume()
    }
    
    private func stopMonitoring() {
        folderMonitor.cancel()
    }
    
    var managedMode = false {
        didSet {
            if (oldValue != managedMode) {
                if (oldValue) {
                    try? self.fileStorage.deleteAll()
                    self.secureMode = false
                    self.locked = false
                }
            }
        }
    }
    
    var secureMode = UserDefaults.init(suiteName: FileProviderConstants.appGroupIdentifier)?.bool(forKey: FileProviderConstants.secureModeUserDefaultsKey) {
        didSet {
            if (oldValue != secureMode)  {
                self.migrate(fromStorage: self.fileStorage)
                let sharedDefaults = UserDefaults.init(suiteName: FileProviderConstants.appGroupIdentifier)
                sharedDefaults?.set(secureMode, forKey: FileProviderConstants.secureModeUserDefaultsKey)
                sharedDefaults?.synchronize()
            }
        }
    }
    
    private(set) var lockReason: String?
    private(set) var locked = false
    func setLocked(_ isLocked: Bool, with reason: String? = nil) {
        self.lockReason = reason
        self.locked = isLocked
        self.refreshFileList()
    }
    
    var numberOfFiles: Int {
        return fileList.count
    }

    func fileName(at index: Int) -> String {
        return fileList[index]
    }
    
    func preparedFileURL(at index: Int) -> URL? {
        return fileStorage.presentationURL(withName: self.fileName(at: index))
    }

    func removeFile(at index: Int) throws {
        try self.fileStorage.deleteFile(withName: self.fileName(at: index))
        self.fileList.remove(at: index)
    }
    
    func importFile(at sourceFileURL: URL) throws {
        try self.fileStorage.consumeFile(at: sourceFileURL)
        self.refreshFileList()
    }
    
    func clear() {
        try? self.fileStorage.deleteAll()
    }
}


