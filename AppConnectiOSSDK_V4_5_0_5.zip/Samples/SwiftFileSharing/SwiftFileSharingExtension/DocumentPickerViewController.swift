//
//  DocumentPickerViewController.swift
//  SwiftFileSharingExtension
//
//  Created on 5/22/18.
//  Copyright © 2018 Mobileiron. All rights reserved.
//

import UIKit
import AppConnectExtension

protocol ExtensionManagerProtocol: class {
    func extensionManager(_ extensionManager: ExtensionManager?, appConnectAccessControlStateDeterminedAs state: ACExtensionAccessState)
}

class ExtensionManager: NSObject, AppConnectExtensionInterfaceProtocol {
    weak var acInterface: AppConnectExtensionInterface?
    weak var delegate: ExtensionManagerProtocol?

    static var sharedInstance: ExtensionManager = {
        var sharedInstance: ExtensionManager? = nil
        var onceToken: Int?
        sharedInstance = ExtensionManager()
        sharedInstance?.acInterface = AppConnectExtensionInterface.appConnectExtensionInstance()
        sharedInstance?.acInterface?.delegate = sharedInstance
        onceToken = 1
        return sharedInstance!
    }()

    func requestAccessControlState() {
        acInterface?.determineAccessControlState()
    }

    func appConnectAccessControlStateDetermined(as state: ACExtensionAccessState) {
        delegate?.extensionManager(self, appConnectAccessControlStateDeterminedAs: state)
    }
}

class DocumentPickerViewController: UIDocumentPickerExtensionViewController, ExtensionManagerProtocol, UITableViewDataSource, UITableViewDelegate  {
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var unavailableReason: UILabel!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    private var isModeSupported = false
    private var fileProvider: ExtensionFileProvider!
    private var currentState: ACExtensionAccessState!

    func extensionManager(_ extensionManager: ExtensionManager?, appConnectAccessControlStateDeterminedAs state: ACExtensionAccessState) {
        currentState = state
        spinner.stopAnimating()
        switch currentState {
        case .noRequest?:
            isModeSupported = false
            tableview.isHidden = true
            unavailableReason.isHidden = false
            unavailableReason.text = "There is no access control request. This means an app with out viewing permission has launched the extension."
        case .notEnabled?:
            isModeSupported = false
            tableview.isHidden = true
            unavailableReason.isHidden = false
            unavailableReason.text = "Either the host application has not enabled access control, or the Access control ID was not set by the admin."
        case .notBlocked?:
            // An appconnect app has launched the extension.
            isModeSupported = true
            tableview.isHidden = false
            unavailableReason.isHidden = true
            fileProvider = ExtensionFileProvider.init()
            tableview.reloadData()
        case .blocked?:
            isModeSupported = false
            tableview.isHidden = true
            unavailableReason.isHidden = false
            unavailableReason.text = "An invalid access control request was made, so the extension should not display secure content."
        case .none, .some(_):
            print("None/Some use case!!!")
            isModeSupported = false
            tableview.isHidden = true
            unavailableReason.isHidden = false
            unavailableReason.text = "Showing extension's content is blocked."
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        isModeSupported = false
        tableview.tableFooterView = UIView(frame: CGRect.zero)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    override func prepareForPresentation(in mode: UIDocumentPickerMode) {
        switch mode {
        case .exportToService, .moveToService:
            unavailableReason.isHidden = false
            tableview.isHidden = true
            isModeSupported = false
            unavailableReason.text = "Export/Move mode is not supported."
        case .open, .import:
            ExtensionManager.sharedInstance.delegate = self
            ExtensionManager.sharedInstance.requestAccessControlState()
            spinner.startAnimating()
        @unknown default:
            break
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard fileProvider != nil else {return 0}
        return fileProvider.numberOfFiles
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileListCell", for: indexPath)
        cell.textLabel?.text = self.fileProvider.fileName(at: indexPath.row)

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedFileURL = self.fileProvider.preparedFileURL(at: indexPath.row)
        let toFileURL = ExtensionFileProvider.tempFolderURL?.appendingPathComponent(self.fileProvider.fileName(at: indexPath.row))
        guard ((selectedFileURL != nil) && (toFileURL != nil)) else {
            print("File URLs are nil selectedFileURL: \(String(describing: selectedFileURL)) toFileURL: \(String(describing: toFileURL))")
            return
        }
        if ExtensionFileProvider.secureMode {
            wrapFileAndShare(at: selectedFileURL, to: toFileURL)
        }
        else {
            do {
                try FileManager.default.moveItem(at: selectedFileURL!, to: toFileURL!)
                self.dismissGrantingAccess(to: toFileURL)
            } catch {
                print("Unable to move file selectedFileURL: \(String(describing: selectedFileURL)) toFileURL: \(String(describing: toFileURL))!")
            }
        }
    }

    func wrapFileAndShare(at url: URL?, to newURL: URL?) {
        let sharedDefaults = UserDefaults.init(suiteName: FileProviderConstants.appGroupIdentifier)
        let wrappedKeysData: Data? = sharedDefaults?.object(forKey: FileProviderConstants.wrappedCryptoDefaultKey) as? Data
        guard wrappedKeysData != nil else {
            print("Wrapped keys missing in defaults")
            dismissGrantingAccess(to: nil)
            return
        }
        do {
            try ACWrappedFile.wrap(atPath: url?.path, toPath: newURL?.path, withCryptoBlock: wrappedKeysData!)
            dismissGrantingAccess(to: newURL)
            return
        } catch {
            print("Unable to wrap file.")
        }
        dismissGrantingAccess(to: nil)
        return
    }
}
