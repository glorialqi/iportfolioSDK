//
//  ExtensionFileProvider.swift
//  SwiftFileSharingExtension
//
//  Created on 5/22/18.
//  Copyright © 2018 Mobileiron. All rights reserved.
//

import UIKit

class ExtensionFileProvider {
    private var fileList = [String]()

    class var continerURL: URL {
        let containerURL = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: FileProviderConstants.appGroupIdentifier)
        guard containerURL != nil else {return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!}
        return containerURL!
    }

    class var documentsFolder: URL {
        let subFolderName = self.secureMode ? ".SecureFiles" : ".Files"
        return continerURL.appendingPathComponent(subFolderName)
    }

    class var tempFolderURL: URL? {
        let tempFolder = continerURL.appendingPathComponent(".temp")
        var isDirectoryFlag: ObjCBool = ObjCBool.init(false)
        FileManager.default.fileExists(atPath: tempFolder.absoluteString, isDirectory: &isDirectoryFlag)
        if !isDirectoryFlag.boolValue {
            do {
                try FileManager.default.createDirectory(at: tempFolder, withIntermediateDirectories: true, attributes: [:])
            } catch {
                return nil
            }
        }
        return tempFolder
    }

    init?() {
        self.processDocumentsFolder()
    }

    private func processDocumentsFolder() {
        let allFiles = (try? FileManager.default.contentsOfDirectory(at: type(of: self).documentsFolder,
                                                                     includingPropertiesForKeys: nil,
                                                                     options: .skipsSubdirectoryDescendants)) ?? []
        for fileURL in allFiles {
            var isDirectoryFlag: ObjCBool = ObjCBool.init(false)
            FileManager.default.fileExists(atPath: fileURL.path, isDirectory: &isDirectoryFlag)
            if (!isDirectoryFlag.boolValue) {
                fileList.append(fileURL.lastPathComponent)
            }
        }
    }

    class var secureMode: Bool {
        return (UserDefaults.init(suiteName: FileProviderConstants.appGroupIdentifier)?.bool(forKey: FileProviderConstants.secureModeUserDefaultsKey))!
    }

    var numberOfFiles: Int {
        return fileList.count
    }

    func fileName(at index: Int) -> String {
        return fileList[index]
    }

    func preparedFileURL(at index: Int) -> URL? {
        return type(of: self).documentsFolder.appendingPathComponent(self.fileName(at: index))
    }
}
