/*!
 * @header AppConnectExtension.h
 *
 * @abstract AppConnectExtension framework umbrella header
 *
 * @copyright Copyright (c) 2013-2018 MobileIron. All rights reserved.
 * <p>YOUR USE AND DISTRIBUTION OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE DEVELOPMENT KIT (SDK) AGREEMENT BETWEEN
 * YOU AND MOBILE IRON, INC. (“MI”).  USE OR DISTRIBUTION NOT IN STRICT ACCORDANCE WITH THE AGREEMENT IS PROHIBITED.</p>
 */


#import <UIKit/UIKit.h>

//! Project version number for AppConnectExtension.
FOUNDATION_EXPORT double AppConnectExtensionVersionNumber;

//! Project version string for AppConnectExtension.
FOUNDATION_EXPORT const unsigned char AppConnectExtensionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppConnectExtension/PublicHeader.h>

#import <AppConnectExtension/AppConnectExtensionInterface.h>
#import <AppConnectExtension/ACWrappedFile.h>
