/*!
 * @header ACWrappedFile.h
 *
 * @abstract Creating wrapped files.
 *
 * @copyright Copyright (c) 2013-2018 MobileIron. All rights reserved.
 * <p>YOUR USE AND DISTRIBUTION OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE DEVELOPMENT KIT (SDK) AGREEMENT BETWEEN
 * YOU AND MOBILE IRON, INC. (“MI”).  USE OR DISTRIBUTION NOT IN STRICT ACCORDANCE WITH THE AGREEMENT IS PROHIBITED.</p>
 */

#import <Foundation/Foundation.h>
/*! Error domain */
extern NSString * const kACWrappedFileCreateErrorDomain;

/*! @typedef ACWrappedFileWriteError
 *  @brief An enum listing all error codes
 */
typedef NS_ENUM(int, ACWrappedFileWriteError) {
    /*! File does not exist. */
    ACWrappedFileWriteErrorFileDoesNotExist,
};

@interface ACWrappedFile: NSObject

/*!
 * Wrap an AppConnect encrypted file so that it can be read by other AppConnect apps.
 * @param path Path to file that needs to be wrapped.
 * @param toPath Path where the wrapped file should be saved.
 * @param cryptoBlock The crypto block used for encrypting the original file. This block can be accessed in the application, using ACWrappedAppKey APIs.
 * @param fileName Actual file name, in case the file name in the path parameter is different.
 * @param error Out parameter to retrieve errors.
 * @return Returns YES in success.
 */
+(BOOL)wrapFileAtPath:(NSString *)path
               toPath:(NSString *)toPath
      withCryptoBlock:(NSData *)cryptoBlock
       actualFileName:(NSString *)fileName
                error:(NSError *__autoreleasing *)error;

/*!
 * Wrap an AppConnect encrypted file, so that it can be read by other AppConnect apps.
 * @param path Path to file that needs to be wrapped.
 * @param toPath Path where the wrapped file should be saved.
 * @param cryptoBlock The crypto block used for encrypting the original file. This block can be accessed in the application, using ACWrappedAppKey APIs.
 * @param error Out parameter to retrieve errors.
 * @return Returns YES in success.
 */
+(BOOL)wrapFileAtPath:(NSString *)path
               toPath:(NSString *)toPath
      withCryptoBlock:(NSData *)cryptoBlock error:(NSError *__autoreleasing *)error;

@end

