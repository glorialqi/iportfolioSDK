/*!
 * @header AppConnectExtensionInterface.h
 *
 * @abstract Central class of AppConnectExtension
 *
 * @copyright Copyright (c) 2013-2018 MobileIron. All rights reserved.
 * <p>YOUR USE AND DISTRIBUTION OF THIS SOFTWARE IS SUBJECT TO THE SOFTWARE DEVELOPMENT KIT (SDK) AGREEMENT BETWEEN
 * YOU AND MOBILE IRON, INC. (“MI”).  USE OR DISTRIBUTION NOT IN STRICT ACCORDANCE WITH THE AGREEMENT IS PROHIBITED.</p>
 */

#import <Foundation/Foundation.h>

/*! @typedef ACExtensionAccessState
 *  @brief An enum listing all extension states
 */
typedef NS_ENUM(int, ACExtensionAccessState) {
    /*! If the state is ACExtensionAccessStateNotEnabled, parent application has not enabled access control or if Access control ID is not set by admin. */
    ACExtensionAccessStateNotEnabled = -1,
    /*! If the state is ACExtensionAccessStateNoRequest, there is no access control request. This means an app with out viewing permission has launched the extension. */
    ACExtensionAccessStateNoRequest = 0,
    /*! If the state is ACExtensionAccessStateNotBlocked, extesnion should display content. This state means that either the extension request is valid, or there is no access control rule set. */
    ACExtensionAccessStateNotBlocked = 1,
    /*! If the state is ACExtensionAccessStateBlocked, extension should block the content. */
    ACExtensionAccessStateBlocked = 2,
};

/*!
 * @abstract This protocol defines methods that will be called after the AppConnectExtension framework has determined the state.
 */
@protocol AppConnectExtensionInterfaceProtocol
@required
/*!
 * This method is called after the the AppConnectExtension framework has completed its checks for
 * determining current access control state.
 * @param state ACExtensionAccessState value giving current state.
 */
-(void)appConnectAccessControlStateDeterminedAs:(ACExtensionAccessState)state;

@end

/*!
 * @abstract AppConnectExtensionInterface is the central class for an extension bundled inside of the AppConnect app.
 */
@interface AppConnectExtensionInterface : NSObject

/*!
 * Delegate conforming to AppConnectExtensionInterfaceProtocol.
 */
@property (nonatomic, weak)id<AppConnectExtensionInterfaceProtocol> delegate;

/*!
 * AppConnectExtension instance. You need to use this instance to request extension operations provided by the AppConnect SDK.
 * @return AppConnectExtension object.
 */
+(instancetype)appConnectExtensionInstance;

/*!
 * This method initiates a process to determine current access control state.
 * App extensions must call this method before showing content.
 * @return YES, if the process for determining the access control state has started. Returns NO if there is an issue.
 */
-(BOOL)determineAccessControlState;
@end
